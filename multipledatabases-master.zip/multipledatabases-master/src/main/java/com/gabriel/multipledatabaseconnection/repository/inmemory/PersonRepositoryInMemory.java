package com.gabriel.multipledatabaseconnection.repository.inmemory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.gabriel.multipledatabaseconnection.model.AccountStatus;

public interface PersonRepositoryInMemory extends JpaRepository<AccountStatus, String>, JpaSpecificationExecutor<AccountStatus> {

	AccountStatus findFirstByAcctCurrentStatus(String idNumber);
}
