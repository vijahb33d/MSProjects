/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gabriel.multipledatabaseconnection.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author 1222270
 */
@Entity
@Table(name = "ACCOUNT_EARNING_CREDIT", catalog = "")
@NamedQueries({
    @NamedQuery(name = "AccountEarningCredit.findAll", query = "SELECT a FROM AccountEarningCredit a"),
    @NamedQuery(name = "AccountEarningCredit.findByCountryCode", query = "SELECT a FROM AccountEarningCredit a WHERE a.accountEarningCreditPK.countryCode = :countryCode"),
    @NamedQuery(name = "AccountEarningCredit.findByCurrencyCode", query = "SELECT a FROM AccountEarningCredit a WHERE a.accountEarningCreditPK.currencyCode = :currencyCode"),
    @NamedQuery(name = "AccountEarningCredit.findByAccountNo", query = "SELECT a FROM AccountEarningCredit a WHERE a.accountEarningCreditPK.accountNo = :accountNo"),
    @NamedQuery(name = "AccountEarningCredit.findByCrmId", query = "SELECT a FROM AccountEarningCredit a WHERE a.crmId = :crmId"),
    @NamedQuery(name = "AccountEarningCredit.findByEarningsFinalRate", query = "SELECT a FROM AccountEarningCredit a WHERE a.earningsFinalRate = :earningsFinalRate"),
    @NamedQuery(name = "AccountEarningCredit.findByEarningsRateDifferential", query = "SELECT a FROM AccountEarningCredit a WHERE a.earningsRateDifferential = :earningsRateDifferential"),
    @NamedQuery(name = "AccountEarningCredit.findByMeb", query = "SELECT a FROM AccountEarningCredit a WHERE a.meb = :meb"),
    @NamedQuery(name = "AccountEarningCredit.findByReduceMebFlag", query = "SELECT a FROM AccountEarningCredit a WHERE a.reduceMebFlag = :reduceMebFlag"),
    @NamedQuery(name = "AccountEarningCredit.findByUpdatedDate", query = "SELECT a FROM AccountEarningCredit a WHERE a.updatedDate = :updatedDate"),
    @NamedQuery(name = "AccountEarningCredit.findByMakerId", query = "SELECT a FROM AccountEarningCredit a WHERE a.makerId = :makerId"),
    @NamedQuery(name = "AccountEarningCredit.findByCheckerId", query = "SELECT a FROM AccountEarningCredit a WHERE a.checkerId = :checkerId"),
    @NamedQuery(name = "AccountEarningCredit.findByMakerDate", query = "SELECT a FROM AccountEarningCredit a WHERE a.makerDate = :makerDate"),
    @NamedQuery(name = "AccountEarningCredit.findByCheckerDate", query = "SELECT a FROM AccountEarningCredit a WHERE a.checkerDate = :checkerDate"),
    @NamedQuery(name = "AccountEarningCredit.findByStatus", query = "SELECT a FROM AccountEarningCredit a WHERE a.status = :status"),
    @NamedQuery(name = "AccountEarningCredit.findByCurrentVersion", query = "SELECT a FROM AccountEarningCredit a WHERE a.currentVersion = :currentVersion"),
    @NamedQuery(name = "AccountEarningCredit.findByCreatedDate", query = "SELECT a FROM AccountEarningCredit a WHERE a.createdDate = :createdDate"),
    @NamedQuery(name = "AccountEarningCredit.findByRateType", query = "SELECT a FROM AccountEarningCredit a WHERE a.rateType = :rateType"),
    @NamedQuery(name = "AccountEarningCredit.findByEarningsSpread", query = "SELECT a FROM AccountEarningCredit a WHERE a.earningsSpread = :earningsSpread"),
    @NamedQuery(name = "AccountEarningCredit.findByEarningCreditAllowedFlag", query = "SELECT a FROM AccountEarningCredit a WHERE a.earningCreditAllowedFlag = :earningCreditAllowedFlag"),
    @NamedQuery(name = "AccountEarningCredit.findByDefaultEarningsCredit", query = "SELECT a FROM AccountEarningCredit a WHERE a.defaultEarningsCredit = :defaultEarningsCredit"),
    @NamedQuery(name = "AccountEarningCredit.findByIsMinBalApplied", query = "SELECT a FROM AccountEarningCredit a WHERE a.isMinBalApplied = :isMinBalApplied"),
    @NamedQuery(name = "AccountEarningCredit.findByIsMinBalIncludesSubAct", query = "SELECT a FROM AccountEarningCredit a WHERE a.isMinBalIncludesSubAct = :isMinBalIncludesSubAct"),
    @NamedQuery(name = "AccountEarningCredit.findByFileId", query = "SELECT a FROM AccountEarningCredit a WHERE a.fileId = :fileId"),
    @NamedQuery(name = "AccountEarningCredit.findByNegativeBalance", query = "SELECT a FROM AccountEarningCredit a WHERE a.negativeBalance = :negativeBalance"),
    @NamedQuery(name = "AccountEarningCredit.findByCapAmount", query = "SELECT a FROM AccountEarningCredit a WHERE a.capAmount = :capAmount"),
    @NamedQuery(name = "AccountEarningCredit.findByReserveBalanceForCharges", query = "SELECT a FROM AccountEarningCredit a WHERE a.reserveBalanceForCharges = :reserveBalanceForCharges"),
    @NamedQuery(name = "AccountEarningCredit.findByBaseRate", query = "SELECT a FROM AccountEarningCredit a WHERE a.baseRate = :baseRate")})
public class AccountEarningCredit implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected AccountEarningCreditPK accountEarningCreditPK;
    @Basic(optional = false)
    @Column(name = "CRM_ID", nullable = false)
    private BigInteger crmId;
    @Column(name = "EARNINGS_FINAL_RATE")
    private BigInteger earningsFinalRate;
    @Column(name = "EARNINGS_RATE_DIFFERENTIAL", length = 1)
    private String earningsRateDifferential;
    @Column(name = "MEB")
    private BigInteger meb;
    @Column(name = "REDUCE_MEB_FLAG")
    private Short reduceMebFlag;
    @Column(name = "UPDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;
    @Basic(optional = false)
    @Column(name = "MAKER_ID", nullable = false, length = 10)
    private String makerId;
    @Column(name = "CHECKER_ID", length = 10)
    private String checkerId;
    @Column(name = "MAKER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date makerDate;
    @Column(name = "CHECKER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date checkerDate;
    @Basic(optional = false)
    @Column(name = "STATUS", nullable = false)
    private short status;
    @Column(name = "CURRENT_VERSION")
    private BigInteger currentVersion;
    @Basic(optional = false)
    @Column(name = "CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Column(name = "RATE_TYPE", length = 6)
    private String rateType;
    @Column(name = "EARNINGS_SPREAD")
    private BigInteger earningsSpread;
    @Column(name = "EARNING_CREDIT_ALLOWED_FLAG")
    private Short earningCreditAllowedFlag;
    @Basic(optional = false)
    @Column(name = "DEFAULT_EARNINGS_CREDIT", nullable = false)
    private short defaultEarningsCredit;
    @Column(name = "IS_MIN_BAL_APPLIED")
    private Short isMinBalApplied;
    @Column(name = "IS_MIN_BAL_INCLUDES_SUB_ACT")
    private Short isMinBalIncludesSubAct;
    @Column(name = "FILE_ID", length = 50)
    private String fileId;
    @Column(name = "NEGATIVE_BALANCE", length = 10)
    private String negativeBalance;
    @Column(name = "CAP_AMOUNT")
    private BigInteger capAmount;
    @Column(name = "RESERVE_BALANCE_FOR_CHARGES")
    private BigInteger reserveBalanceForCharges;
    @Column(name = "BASE_RATE")
    private BigInteger baseRate;

    public AccountEarningCredit() {
    }

    public AccountEarningCredit(AccountEarningCreditPK accountEarningCreditPK) {
        this.accountEarningCreditPK = accountEarningCreditPK;
    }

    public AccountEarningCredit(AccountEarningCreditPK accountEarningCreditPK, BigInteger crmId, String makerId, short status, Date createdDate, short defaultEarningsCredit) {
        this.accountEarningCreditPK = accountEarningCreditPK;
        this.crmId = crmId;
        this.makerId = makerId;
        this.status = status;
        this.createdDate = createdDate;
        this.defaultEarningsCredit = defaultEarningsCredit;
    }

    public AccountEarningCredit(String countryCode, String currencyCode, String accountNo) {
        this.accountEarningCreditPK = new AccountEarningCreditPK(countryCode, currencyCode, accountNo);
    }

    public AccountEarningCreditPK getAccountEarningCreditPK() {
        return accountEarningCreditPK;
    }

    public void setAccountEarningCreditPK(AccountEarningCreditPK accountEarningCreditPK) {
        this.accountEarningCreditPK = accountEarningCreditPK;
    }

    public BigInteger getCrmId() {
        return crmId;
    }

    public void setCrmId(BigInteger crmId) {
        this.crmId = crmId;
    }

    public BigInteger getEarningsFinalRate() {
        return earningsFinalRate;
    }

    public void setEarningsFinalRate(BigInteger earningsFinalRate) {
        this.earningsFinalRate = earningsFinalRate;
    }

    public String getEarningsRateDifferential() {
        return earningsRateDifferential;
    }

    public void setEarningsRateDifferential(String earningsRateDifferential) {
        this.earningsRateDifferential = earningsRateDifferential;
    }

    public BigInteger getMeb() {
        return meb;
    }

    public void setMeb(BigInteger meb) {
        this.meb = meb;
    }

    public Short getReduceMebFlag() {
        return reduceMebFlag;
    }

    public void setReduceMebFlag(Short reduceMebFlag) {
        this.reduceMebFlag = reduceMebFlag;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getMakerId() {
        return makerId;
    }

    public void setMakerId(String makerId) {
        this.makerId = makerId;
    }

    public String getCheckerId() {
        return checkerId;
    }

    public void setCheckerId(String checkerId) {
        this.checkerId = checkerId;
    }

    public Date getMakerDate() {
        return makerDate;
    }

    public void setMakerDate(Date makerDate) {
        this.makerDate = makerDate;
    }

    public Date getCheckerDate() {
        return checkerDate;
    }

    public void setCheckerDate(Date checkerDate) {
        this.checkerDate = checkerDate;
    }

    public short getStatus() {
        return status;
    }

    public void setStatus(short status) {
        this.status = status;
    }

    public BigInteger getCurrentVersion() {
        return currentVersion;
    }

    public void setCurrentVersion(BigInteger currentVersion) {
        this.currentVersion = currentVersion;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getRateType() {
        return rateType;
    }

    public void setRateType(String rateType) {
        this.rateType = rateType;
    }

    public BigInteger getEarningsSpread() {
        return earningsSpread;
    }

    public void setEarningsSpread(BigInteger earningsSpread) {
        this.earningsSpread = earningsSpread;
    }

    public Short getEarningCreditAllowedFlag() {
        return earningCreditAllowedFlag;
    }

    public void setEarningCreditAllowedFlag(Short earningCreditAllowedFlag) {
        this.earningCreditAllowedFlag = earningCreditAllowedFlag;
    }

    public short getDefaultEarningsCredit() {
        return defaultEarningsCredit;
    }

    public void setDefaultEarningsCredit(short defaultEarningsCredit) {
        this.defaultEarningsCredit = defaultEarningsCredit;
    }

    public Short getIsMinBalApplied() {
        return isMinBalApplied;
    }

    public void setIsMinBalApplied(Short isMinBalApplied) {
        this.isMinBalApplied = isMinBalApplied;
    }

    public Short getIsMinBalIncludesSubAct() {
        return isMinBalIncludesSubAct;
    }

    public void setIsMinBalIncludesSubAct(Short isMinBalIncludesSubAct) {
        this.isMinBalIncludesSubAct = isMinBalIncludesSubAct;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getNegativeBalance() {
        return negativeBalance;
    }

    public void setNegativeBalance(String negativeBalance) {
        this.negativeBalance = negativeBalance;
    }

    public BigInteger getCapAmount() {
        return capAmount;
    }

    public void setCapAmount(BigInteger capAmount) {
        this.capAmount = capAmount;
    }

    public BigInteger getReserveBalanceForCharges() {
        return reserveBalanceForCharges;
    }

    public void setReserveBalanceForCharges(BigInteger reserveBalanceForCharges) {
        this.reserveBalanceForCharges = reserveBalanceForCharges;
    }

    public BigInteger getBaseRate() {
        return baseRate;
    }

    public void setBaseRate(BigInteger baseRate) {
        this.baseRate = baseRate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (accountEarningCreditPK != null ? accountEarningCreditPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AccountEarningCredit)) {
            return false;
        }
        AccountEarningCredit other = (AccountEarningCredit) object;
        if ((this.accountEarningCreditPK == null && other.accountEarningCreditPK != null) || (this.accountEarningCreditPK != null && !this.accountEarningCreditPK.equals(other.accountEarningCreditPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.AccountEarningCredit[accountEarningCreditPK=" + accountEarningCreditPK + "]";
    }

}
