package com.gabriel.multipledatabaseconnection.repository.persistent;

import com.gabriel.multipledatabaseconnection.model.AccountStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface PersonRepositoryPersistent extends JpaRepository<AccountStatus, String>, JpaSpecificationExecutor<AccountStatus> {

    AccountStatus findFirstByAcctCurrentStatus(String idNumber);
}
