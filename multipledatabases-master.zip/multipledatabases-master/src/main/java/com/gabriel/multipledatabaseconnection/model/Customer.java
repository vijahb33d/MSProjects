/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gabriel.multipledatabaseconnection.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author 1222270
 */
@Entity
@Table(name = "CUSTOMER", catalog = "")
@NamedQueries({
    @NamedQuery(name = "Customer.findAll", query = "SELECT c FROM Customer c"),
    @NamedQuery(name = "Customer.findByCountryCode", query = "SELECT c FROM Customer c WHERE c.customerPK.countryCode = :countryCode"),
    @NamedQuery(name = "Customer.findByMasterNo", query = "SELECT c FROM Customer c WHERE c.customerPK.masterNo = :masterNo"),
    @NamedQuery(name = "Customer.findByUltimateCntryCode", query = "SELECT c FROM Customer c WHERE c.ultimateCntryCode = :ultimateCntryCode"),
    @NamedQuery(name = "Customer.findByBranchCode", query = "SELECT c FROM Customer c WHERE c.branchCode = :branchCode"),
    @NamedQuery(name = "Customer.findByArmCode", query = "SELECT c FROM Customer c WHERE c.armCode = :armCode"),
    @NamedQuery(name = "Customer.findByShortName", query = "SELECT c FROM Customer c WHERE c.shortName = :shortName"),
    @NamedQuery(name = "Customer.findBySegmentCode", query = "SELECT c FROM Customer c WHERE c.segmentCode = :segmentCode"),
    @NamedQuery(name = "Customer.findByInstClassCode", query = "SELECT c FROM Customer c WHERE c.instClassCode = :instClassCode"),
    @NamedQuery(name = "Customer.findByReviewDate", query = "SELECT c FROM Customer c WHERE c.reviewDate = :reviewDate"),
    @NamedQuery(name = "Customer.findByInterGroupCode", query = "SELECT c FROM Customer c WHERE c.interGroupCode = :interGroupCode"),
    @NamedQuery(name = "Customer.findByGenerateTinFlag", query = "SELECT c FROM Customer c WHERE c.generateTinFlag = :generateTinFlag"),
    @NamedQuery(name = "Customer.findByIsicCode", query = "SELECT c FROM Customer c WHERE c.isicCode = :isicCode"),
    @NamedQuery(name = "Customer.findByResidencyClsCode", query = "SELECT c FROM Customer c WHERE c.residencyClsCode = :residencyClsCode"),
    @NamedQuery(name = "Customer.findByPrintAdviceFlag", query = "SELECT c FROM Customer c WHERE c.printAdviceFlag = :printAdviceFlag"),
    @NamedQuery(name = "Customer.findByCustSegmtCode", query = "SELECT c FROM Customer c WHERE c.custSegmtCode = :custSegmtCode"),
    @NamedQuery(name = "Customer.findByCustTypeCode", query = "SELECT c FROM Customer c WHERE c.custTypeCode = :custTypeCode"),
    @NamedQuery(name = "Customer.findByExtendedReviewDate", query = "SELECT c FROM Customer c WHERE c.extendedReviewDate = :extendedReviewDate"),
    @NamedQuery(name = "Customer.findByResidentStatus", query = "SELECT c FROM Customer c WHERE c.residentStatus = :residentStatus"),
    @NamedQuery(name = "Customer.findByAcctType", query = "SELECT c FROM Customer c WHERE c.acctType = :acctType"),
    @NamedQuery(name = "Customer.findByMasterOpenDate", query = "SELECT c FROM Customer c WHERE c.masterOpenDate = :masterOpenDate"),
    @NamedQuery(name = "Customer.findByClosingDate", query = "SELECT c FROM Customer c WHERE c.closingDate = :closingDate"),
    @NamedQuery(name = "Customer.findByParentCompCntry", query = "SELECT c FROM Customer c WHERE c.parentCompCntry = :parentCompCntry"),
    @NamedQuery(name = "Customer.findByGroupCode", query = "SELECT c FROM Customer c WHERE c.groupCode = :groupCode"),
    @NamedQuery(name = "Customer.findBySciReferenceNo", query = "SELECT c FROM Customer c WHERE c.sciReferenceNo = :sciReferenceNo"),
    @NamedQuery(name = "Customer.findByBusClsCode", query = "SELECT c FROM Customer c WHERE c.busClsCode = :busClsCode"),
    @NamedQuery(name = "Customer.findByOrgArmCode", query = "SELECT c FROM Customer c WHERE c.orgArmCode = :orgArmCode"),
    @NamedQuery(name = "Customer.findByCustStatus", query = "SELECT c FROM Customer c WHERE c.custStatus = :custStatus"),
    @NamedQuery(name = "Customer.findByUpdatedDate", query = "SELECT c FROM Customer c WHERE c.updatedDate = :updatedDate"),
    @NamedQuery(name = "Customer.findByMakerId", query = "SELECT c FROM Customer c WHERE c.makerId = :makerId"),
    @NamedQuery(name = "Customer.findByCheckerId", query = "SELECT c FROM Customer c WHERE c.checkerId = :checkerId"),
    @NamedQuery(name = "Customer.findByMakerDate", query = "SELECT c FROM Customer c WHERE c.makerDate = :makerDate"),
    @NamedQuery(name = "Customer.findByCheckerDate", query = "SELECT c FROM Customer c WHERE c.checkerDate = :checkerDate"),
    @NamedQuery(name = "Customer.findByStatus", query = "SELECT c FROM Customer c WHERE c.status = :status"),
    @NamedQuery(name = "Customer.findByCurrentVersion", query = "SELECT c FROM Customer c WHERE c.currentVersion = :currentVersion"),
    @NamedQuery(name = "Customer.findByCreatedDate", query = "SELECT c FROM Customer c WHERE c.createdDate = :createdDate"),
    @NamedQuery(name = "Customer.findByCurrentGpbsIndicator", query = "SELECT c FROM Customer c WHERE c.currentGpbsIndicator = :currentGpbsIndicator"),
    @NamedQuery(name = "Customer.findByNewGpbsIndicator", query = "SELECT c FROM Customer c WHERE c.newGpbsIndicator = :newGpbsIndicator"),
    @NamedQuery(name = "Customer.findByNewGpbsIndEffDate", query = "SELECT c FROM Customer c WHERE c.newGpbsIndEffDate = :newGpbsIndEffDate"),
    @NamedQuery(name = "Customer.findByCustStatusDv", query = "SELECT c FROM Customer c WHERE c.custStatusDv = :custStatusDv"),
    @NamedQuery(name = "Customer.findBySegmentCodeDv", query = "SELECT c FROM Customer c WHERE c.segmentCodeDv = :segmentCodeDv"),
    @NamedQuery(name = "Customer.findByCustCategoryDv", query = "SELECT c FROM Customer c WHERE c.custCategoryDv = :custCategoryDv"),
    @NamedQuery(name = "Customer.findByFullName", query = "SELECT c FROM Customer c WHERE c.fullName = :fullName"),
    @NamedQuery(name = "Customer.findByCompanyRegistrationNumber", query = "SELECT c FROM Customer c WHERE c.companyRegistrationNumber = :companyRegistrationNumber"),
    @NamedQuery(name = "Customer.findByPassportNumber", query = "SELECT c FROM Customer c WHERE c.passportNumber = :passportNumber"),
    @NamedQuery(name = "Customer.findByArmType", query = "SELECT c FROM Customer c WHERE c.armType = :armType"),
    @NamedQuery(name = "Customer.findByArmTypeDomainValue", query = "SELECT c FROM Customer c WHERE c.armTypeDomainValue = :armTypeDomainValue"),
    @NamedQuery(name = "Customer.findByArmCategory", query = "SELECT c FROM Customer c WHERE c.armCategory = :armCategory"),
    @NamedQuery(name = "Customer.findByArmCategoryDomainValue", query = "SELECT c FROM Customer c WHERE c.armCategoryDomainValue = :armCategoryDomainValue"),
    @NamedQuery(name = "Customer.findByArmName", query = "SELECT c FROM Customer c WHERE c.armName = :armName"),
    @NamedQuery(name = "Customer.findByCustGstRegNo", query = "SELECT c FROM Customer c WHERE c.custGstRegNo = :custGstRegNo"),
    @NamedQuery(name = "Customer.findByVatRegno", query = "SELECT c FROM Customer c WHERE c.vatRegno = :vatRegno"),
    @NamedQuery(name = "Customer.findByAffiliateCode", query = "SELECT c FROM Customer c WHERE c.affiliateCode = :affiliateCode"),
    @NamedQuery(name = "Customer.findByCustGstRegNoOriginal", query = "SELECT c FROM Customer c WHERE c.custGstRegNoOriginal = :custGstRegNoOriginal")})
public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CustomerPK customerPK;
    @Column(name = "ULTIMATE_CNTRY_CODE", length = 2)
    private String ultimateCntryCode;
    @Column(name = "BRANCH_CODE", length = 5)
    private String branchCode;
    @Column(name = "ARM_CODE", length = 9)
    private String armCode;
    @Basic(optional = false)
    @Column(name = "SHORT_NAME", nullable = false, length = 110)
    private String shortName;
    @Column(name = "SEGMENT_CODE", length = 2)
    private String segmentCode;
    @Column(name = "INST_CLASS_CODE", length = 3)
    private String instClassCode;
    @Column(name = "REVIEW_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date reviewDate;
    @Column(name = "INTER_GROUP_CODE", length = 2)
    private String interGroupCode;
    @Basic(optional = false)
    @Column(name = "GENERATE_TIN_FLAG", nullable = false)
    private short generateTinFlag;
    @Column(name = "ISIC_CODE", length = 6)
    private String isicCode;
    @Column(name = "RESIDENCY_CLS_CODE", length = 2)
    private String residencyClsCode;
    @Basic(optional = false)
    @Column(name = "PRINT_ADVICE_FLAG", nullable = false)
    private short printAdviceFlag;
    @Column(name = "CUST_SEGMT_CODE", length = 3)
    private String custSegmtCode;
    @Column(name = "CUST_TYPE_CODE", length = 3)
    private String custTypeCode;
    @Column(name = "EXTENDED_REVIEW_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date extendedReviewDate;
    @Column(name = "RESIDENT_STATUS", length = 1)
    private String residentStatus;
    @Basic(optional = false)
    @Column(name = "ACCT_TYPE", nullable = false, length = 1)
    private String acctType;
    @Basic(optional = false)
    @Column(name = "MASTER_OPEN_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date masterOpenDate;
    @Column(name = "CLOSING_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date closingDate;
    @Column(name = "PARENT_COMP_CNTRY", length = 2)
    private String parentCompCntry;
    @Column(name = "GROUP_CODE", length = 8)
    private String groupCode;
    @Column(name = "SCI_REFERENCE_NO", length = 20)
    private String sciReferenceNo;
    @Column(name = "BUS_CLS_CODE", length = 8)
    private String busClsCode;
    @Column(name = "ORG_ARM_CODE", length = 3)
    private String orgArmCode;
    @Column(name = "CUST_STATUS")
    private Short custStatus;
    @Basic(optional = false)
    @Column(name = "UPDATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;
    @Basic(optional = false)
    @Column(name = "MAKER_ID", nullable = false, length = 10)
    private String makerId;
    @Column(name = "CHECKER_ID", length = 10)
    private String checkerId;
    @Column(name = "MAKER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date makerDate;
    @Column(name = "CHECKER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date checkerDate;
    @Basic(optional = false)
    @Column(name = "STATUS", nullable = false)
    private short status;
    @Column(name = "CURRENT_VERSION")
    private BigInteger currentVersion;
    @Basic(optional = false)
    @Column(name = "CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Column(name = "CURRENT_GPBS_INDICATOR")
    private Short currentGpbsIndicator;
    @Column(name = "NEW_GPBS_INDICATOR")
    private Short newGpbsIndicator;
    @Column(name = "NEW_GPBS_IND_EFF_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date newGpbsIndEffDate;
    @Column(name = "CUST_STATUS_DV")
    private Short custStatusDv;
    @Column(name = "SEGMENT_CODE_DV")
    private Short segmentCodeDv;
    @Column(name = "CUST_CATEGORY_DV")
    private Short custCategoryDv;
    @Column(name = "FULL_NAME", length = 110)
    private String fullName;
    @Column(name = "COMPANY_REGISTRATION_NUMBER", length = 24)
    private String companyRegistrationNumber;
    @Column(name = "PASSPORT_NUMBER", length = 24)
    private String passportNumber;
    @Column(name = "ARM_TYPE")
    private Short armType;
    @Column(name = "ARM_TYPE_DOMAIN_VALUE")
    private Short armTypeDomainValue;
    @Column(name = "ARM_CATEGORY")
    private Short armCategory;
    @Column(name = "ARM_CATEGORY_DOMAIN_VALUE")
    private Short armCategoryDomainValue;
    @Column(name = "ARM_NAME", length = 36)
    private String armName;
    @Column(name = "CUST_GST_REG_NO", length = 20)
    private String custGstRegNo;
    @Column(name = "VAT_REGNO", length = 50)
    private String vatRegno;
    @Column(name = "AFFILIATE_CODE", length = 10)
    private String affiliateCode;
    @Column(name = "CUST_GST_REG_NO_ORIGINAL", length = 20)
    private String custGstRegNoOriginal;

    public Customer() {
    }

    public Customer(CustomerPK customerPK) {
        this.customerPK = customerPK;
    }

    public Customer(CustomerPK customerPK, String shortName, short generateTinFlag, short printAdviceFlag, String acctType, Date masterOpenDate, Date updatedDate, String makerId, short status, Date createdDate) {
        this.customerPK = customerPK;
        this.shortName = shortName;
        this.generateTinFlag = generateTinFlag;
        this.printAdviceFlag = printAdviceFlag;
        this.acctType = acctType;
        this.masterOpenDate = masterOpenDate;
        this.updatedDate = updatedDate;
        this.makerId = makerId;
        this.status = status;
        this.createdDate = createdDate;
    }

    public Customer(String countryCode, String masterNo) {
        this.customerPK = new CustomerPK(countryCode, masterNo);
    }

    public CustomerPK getCustomerPK() {
        return customerPK;
    }

    public void setCustomerPK(CustomerPK customerPK) {
        this.customerPK = customerPK;
    }

    public String getUltimateCntryCode() {
        return ultimateCntryCode;
    }

    public void setUltimateCntryCode(String ultimateCntryCode) {
        this.ultimateCntryCode = ultimateCntryCode;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getArmCode() {
        return armCode;
    }

    public void setArmCode(String armCode) {
        this.armCode = armCode;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getSegmentCode() {
        return segmentCode;
    }

    public void setSegmentCode(String segmentCode) {
        this.segmentCode = segmentCode;
    }

    public String getInstClassCode() {
        return instClassCode;
    }

    public void setInstClassCode(String instClassCode) {
        this.instClassCode = instClassCode;
    }

    public Date getReviewDate() {
        return reviewDate;
    }

    public void setReviewDate(Date reviewDate) {
        this.reviewDate = reviewDate;
    }

    public String getInterGroupCode() {
        return interGroupCode;
    }

    public void setInterGroupCode(String interGroupCode) {
        this.interGroupCode = interGroupCode;
    }

    public short getGenerateTinFlag() {
        return generateTinFlag;
    }

    public void setGenerateTinFlag(short generateTinFlag) {
        this.generateTinFlag = generateTinFlag;
    }

    public String getIsicCode() {
        return isicCode;
    }

    public void setIsicCode(String isicCode) {
        this.isicCode = isicCode;
    }

    public String getResidencyClsCode() {
        return residencyClsCode;
    }

    public void setResidencyClsCode(String residencyClsCode) {
        this.residencyClsCode = residencyClsCode;
    }

    public short getPrintAdviceFlag() {
        return printAdviceFlag;
    }

    public void setPrintAdviceFlag(short printAdviceFlag) {
        this.printAdviceFlag = printAdviceFlag;
    }

    public String getCustSegmtCode() {
        return custSegmtCode;
    }

    public void setCustSegmtCode(String custSegmtCode) {
        this.custSegmtCode = custSegmtCode;
    }

    public String getCustTypeCode() {
        return custTypeCode;
    }

    public void setCustTypeCode(String custTypeCode) {
        this.custTypeCode = custTypeCode;
    }

    public Date getExtendedReviewDate() {
        return extendedReviewDate;
    }

    public void setExtendedReviewDate(Date extendedReviewDate) {
        this.extendedReviewDate = extendedReviewDate;
    }

    public String getResidentStatus() {
        return residentStatus;
    }

    public void setResidentStatus(String residentStatus) {
        this.residentStatus = residentStatus;
    }

    public String getAcctType() {
        return acctType;
    }

    public void setAcctType(String acctType) {
        this.acctType = acctType;
    }

    public Date getMasterOpenDate() {
        return masterOpenDate;
    }

    public void setMasterOpenDate(Date masterOpenDate) {
        this.masterOpenDate = masterOpenDate;
    }

    public Date getClosingDate() {
        return closingDate;
    }

    public void setClosingDate(Date closingDate) {
        this.closingDate = closingDate;
    }

    public String getParentCompCntry() {
        return parentCompCntry;
    }

    public void setParentCompCntry(String parentCompCntry) {
        this.parentCompCntry = parentCompCntry;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getSciReferenceNo() {
        return sciReferenceNo;
    }

    public void setSciReferenceNo(String sciReferenceNo) {
        this.sciReferenceNo = sciReferenceNo;
    }

    public String getBusClsCode() {
        return busClsCode;
    }

    public void setBusClsCode(String busClsCode) {
        this.busClsCode = busClsCode;
    }

    public String getOrgArmCode() {
        return orgArmCode;
    }

    public void setOrgArmCode(String orgArmCode) {
        this.orgArmCode = orgArmCode;
    }

    public Short getCustStatus() {
        return custStatus;
    }

    public void setCustStatus(Short custStatus) {
        this.custStatus = custStatus;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getMakerId() {
        return makerId;
    }

    public void setMakerId(String makerId) {
        this.makerId = makerId;
    }

    public String getCheckerId() {
        return checkerId;
    }

    public void setCheckerId(String checkerId) {
        this.checkerId = checkerId;
    }

    public Date getMakerDate() {
        return makerDate;
    }

    public void setMakerDate(Date makerDate) {
        this.makerDate = makerDate;
    }

    public Date getCheckerDate() {
        return checkerDate;
    }

    public void setCheckerDate(Date checkerDate) {
        this.checkerDate = checkerDate;
    }

    public short getStatus() {
        return status;
    }

    public void setStatus(short status) {
        this.status = status;
    }

    public BigInteger getCurrentVersion() {
        return currentVersion;
    }

    public void setCurrentVersion(BigInteger currentVersion) {
        this.currentVersion = currentVersion;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Short getCurrentGpbsIndicator() {
        return currentGpbsIndicator;
    }

    public void setCurrentGpbsIndicator(Short currentGpbsIndicator) {
        this.currentGpbsIndicator = currentGpbsIndicator;
    }

    public Short getNewGpbsIndicator() {
        return newGpbsIndicator;
    }

    public void setNewGpbsIndicator(Short newGpbsIndicator) {
        this.newGpbsIndicator = newGpbsIndicator;
    }

    public Date getNewGpbsIndEffDate() {
        return newGpbsIndEffDate;
    }

    public void setNewGpbsIndEffDate(Date newGpbsIndEffDate) {
        this.newGpbsIndEffDate = newGpbsIndEffDate;
    }

    public Short getCustStatusDv() {
        return custStatusDv;
    }

    public void setCustStatusDv(Short custStatusDv) {
        this.custStatusDv = custStatusDv;
    }

    public Short getSegmentCodeDv() {
        return segmentCodeDv;
    }

    public void setSegmentCodeDv(Short segmentCodeDv) {
        this.segmentCodeDv = segmentCodeDv;
    }

    public Short getCustCategoryDv() {
        return custCategoryDv;
    }

    public void setCustCategoryDv(Short custCategoryDv) {
        this.custCategoryDv = custCategoryDv;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getCompanyRegistrationNumber() {
        return companyRegistrationNumber;
    }

    public void setCompanyRegistrationNumber(String companyRegistrationNumber) {
        this.companyRegistrationNumber = companyRegistrationNumber;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    public Short getArmType() {
        return armType;
    }

    public void setArmType(Short armType) {
        this.armType = armType;
    }

    public Short getArmTypeDomainValue() {
        return armTypeDomainValue;
    }

    public void setArmTypeDomainValue(Short armTypeDomainValue) {
        this.armTypeDomainValue = armTypeDomainValue;
    }

    public Short getArmCategory() {
        return armCategory;
    }

    public void setArmCategory(Short armCategory) {
        this.armCategory = armCategory;
    }

    public Short getArmCategoryDomainValue() {
        return armCategoryDomainValue;
    }

    public void setArmCategoryDomainValue(Short armCategoryDomainValue) {
        this.armCategoryDomainValue = armCategoryDomainValue;
    }

    public String getArmName() {
        return armName;
    }

    public void setArmName(String armName) {
        this.armName = armName;
    }

    public String getCustGstRegNo() {
        return custGstRegNo;
    }

    public void setCustGstRegNo(String custGstRegNo) {
        this.custGstRegNo = custGstRegNo;
    }

    public String getVatRegno() {
        return vatRegno;
    }

    public void setVatRegno(String vatRegno) {
        this.vatRegno = vatRegno;
    }

    public String getAffiliateCode() {
        return affiliateCode;
    }

    public void setAffiliateCode(String affiliateCode) {
        this.affiliateCode = affiliateCode;
    }

    public String getCustGstRegNoOriginal() {
        return custGstRegNoOriginal;
    }

    public void setCustGstRegNoOriginal(String custGstRegNoOriginal) {
        this.custGstRegNoOriginal = custGstRegNoOriginal;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (customerPK != null ? customerPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Customer)) {
            return false;
        }
        Customer other = (Customer) object;
        if ((this.customerPK == null && other.customerPK != null) || (this.customerPK != null && !this.customerPK.equals(other.customerPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.Customer[customerPK=" + customerPK + "]";
    }

}
