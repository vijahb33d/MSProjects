package com.gabriel.multipledatabaseconnection.repository.persistent;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.gabriel.multipledatabaseconnection.model.AccountEarningCredit;
import com.gabriel.multipledatabaseconnection.model.AccountEarningCreditPK;

public interface AccountEarningCreditRepositoryPersistent extends JpaRepository<AccountEarningCredit, AccountEarningCreditPK>, JpaSpecificationExecutor<AccountEarningCredit> {

	List<AccountEarningCredit> findByAccountEarningCreditPK_countryCode(String idNumber);
}
