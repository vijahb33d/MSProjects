package com.gabriel.multipledatabaseconnection.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.gabriel.multipledatabaseconnection.model.AccountEarningCredit;
import com.gabriel.multipledatabaseconnection.model.AccountStatus;
import com.gabriel.multipledatabaseconnection.model.Customer;
import com.gabriel.multipledatabaseconnection.repository.inmemory.AccountEarningCreditRepositoryMemory;
import com.gabriel.multipledatabaseconnection.repository.inmemory.CustomerRepositoryInMemory;
import com.gabriel.multipledatabaseconnection.repository.inmemory.PersonRepositoryInMemory;
import com.gabriel.multipledatabaseconnection.repository.persistent.AccountEarningCreditRepositoryPersistent;
import com.gabriel.multipledatabaseconnection.repository.persistent.CustomerRepositoryPersistent;
import com.gabriel.multipledatabaseconnection.repository.persistent.PersonRepositoryPersistent;

@EnableTransactionManagement
@RestController
@RequestMapping(value = "/api/person/")
public class MultipleDatabaseController {

    @Autowired
    private PersonRepositoryPersistent personRepositoryPersistent;

    @Autowired
    private PersonRepositoryInMemory personRepositoryInMemory;
    
    private List<AccountStatus> listOfAccountStatus = new ArrayList<AccountStatus>();

    @RequestMapping(value = "getAccountStatus/{id}" , method = RequestMethod.GET, headers = "Accept=application/json")
    public List<AccountStatus> savePerson(@PathVariable int id) {
        return savePersonPersistent(savePersonInMemory(getAllPersistentStatus()));
    }

    @Transactional("persistentDatabaseTransactionManager")
    public List<AccountStatus> getAllPersistentStatus() {
    	listOfAccountStatus = personRepositoryPersistent.findAll();
    	return listOfAccountStatus;
    }
    
    @Transactional("persistentDatabaseTransactionManager")
    public List<AccountStatus>  savePersonPersistent(@RequestBody List<AccountStatus> accountStatusList) {    	
        return personRepositoryPersistent.saveAll(accountStatusList);
    }

    @Transactional("inmemoryDatabaseTransactionManager")
    public List<AccountStatus> savePersonInMemory(List<AccountStatus> accountStatusList) {
        return personRepositoryInMemory.saveAll(accountStatusList);
    }
    
    @Autowired
    private CustomerRepositoryPersistent custRepositoryPersistent;

    @Autowired
    private CustomerRepositoryInMemory custRepositoryInMemory;
    
    String listOfCountries = "AE,AO,BD,BH,BN,BW,CI,CM,CN,DE,GH,GM,HK,ID,IN,IQ,JO,JP,KE,KH,LK,MO,MU,MY,MZ,NG,NP,OM,PH,PK,QA,SG,SL,TH,TW,TZ,UG,US,VN,XG,ZA,ZM,ZW";
    
    private List<Customer> listOfCustomers = new ArrayList<Customer>();
    
    @RequestMapping(value = "getCustomers/{countryCode}" , method = RequestMethod.GET, headers = "Accept=application/json")
    public Customer saveAccount(@PathVariable String countryCode) {
    	long startTime = System.currentTimeMillis();
    	List<Customer> localList = null;
    	String[] countrySplit = listOfCountries.split(",");
    	for (int i=0 ; i < countrySplit.length ; i++) {
    		String countryCode1 = countrySplit[i];
    		localList = saveCustInMemory(getAllCustomer(countryCode1));
            long endTime = System.currentTimeMillis();
            System.out.println("Data Persisting Time to "+countryCode1+" --> "+(endTime-startTime)/60000);        	
    	}
    	return localList.get(0);
    }

    @RequestMapping(value = "getTotalCustomer/{countryCode}" , method = RequestMethod.GET, headers = "Accept=application/json")
    @Transactional("persistentDatabaseTransactionManager")
    public List<Customer> getAllCustomer(@PathVariable String countryCode) {
    	long startTime = System.currentTimeMillis();
    	if(! countryCode.equals("ALL")) {
    		listOfCustomers = custRepositoryPersistent.findByCustomerPK_countryCode(countryCode);
    	} else {
    		listOfCustomers = custRepositoryPersistent.findAll();
    	}
    	
    	long endTime = System.currentTimeMillis();
    	System.out.println("Data Retrieveal Time --> "+(endTime-startTime)/60000);
    	return listOfCustomers;
    }
    
    @Transactional("persistentDatabaseTransactionManager")
    public List<Customer>  saveCustPersistent(@RequestBody List<Customer> accountStatusList) {    	
        return custRepositoryPersistent.saveAll(accountStatusList);
    }

    @Transactional("inmemoryDatabaseTransactionManager")
    public List<Customer> saveCustInMemory(List<Customer> accountStatusList) {
        return custRepositoryInMemory.saveAll(accountStatusList);
    }
    
    @Autowired
    private AccountEarningCreditRepositoryPersistent accCreditRepoPersistent;

    @Autowired
    private AccountEarningCreditRepositoryMemory accCreditRepoMemory;
    
    private List<AccountEarningCredit> listOfAccCredits = new ArrayList<AccountEarningCredit>();
    
    @RequestMapping(value = "getAccEarnCredit/{countryCode}" , method = RequestMethod.GET, headers = "Accept=application/json")
    public AccountEarningCredit saveAccEarnCredit(@PathVariable String countryCode) {
    	long startTime = System.currentTimeMillis();
    	List<AccountEarningCredit> localList = null;
    	String[] countrySplit = listOfCountries.split(",");
    	for (int i=0 ; i < countrySplit.length ; i++) {
    		String countryCode1 = countrySplit[i];
    		localList = saveAccEarnInMemory(getAllAccEarnCredit(countryCode1));
            long endTime = System.currentTimeMillis();
            System.out.println("Data Persisting Time to "+countryCode1+" --> "+(endTime-startTime)/60000);        	
    	}
    	return localList.get(0);
    }

    @RequestMapping(value = "getTotalAccEarnCredit/{countryCode}" , method = RequestMethod.GET, headers = "Accept=application/json")
    @Transactional("persistentDatabaseTransactionManager")
    public List<AccountEarningCredit> getAllAccEarnCredit(@PathVariable String countryCode) {
    	long startTime = System.currentTimeMillis();
    	if(! countryCode.equals("ALL")) {
    		listOfAccCredits=accCreditRepoPersistent.findByAccountEarningCreditPK_countryCode(countryCode);
    	} else {
    		listOfAccCredits=accCreditRepoPersistent.findAll();
    	}    	
    	long endTime = System.currentTimeMillis();
    	System.out.println("Data Retrieveal Time --> "+countryCode+" --> "+(endTime-startTime)/60000);
    	return listOfAccCredits;
    }
    
    @Transactional("persistentDatabaseTransactionManager")
    public List<AccountEarningCredit>  saveAccEarnPersistent(@RequestBody List<AccountEarningCredit> accountStatusList) {    	
        return accCreditRepoPersistent.saveAll(accountStatusList);
    }

    @Transactional("inmemoryDatabaseTransactionManager")
    public List<AccountEarningCredit> saveAccEarnInMemory(List<AccountEarningCredit> accountStatusList) {
        return accCreditRepoMemory.saveAll(accountStatusList);
    }
    
}
