package com.gabriel.multipledatabaseconnection.repository.persistent;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.gabriel.multipledatabaseconnection.model.Customer;
import com.gabriel.multipledatabaseconnection.model.CustomerPK;

public interface CustomerRepositoryPersistent extends JpaRepository<Customer, CustomerPK>, JpaSpecificationExecutor<Customer> {

	List<Customer> findByCustomerPK_countryCode(String idNumber);
}

