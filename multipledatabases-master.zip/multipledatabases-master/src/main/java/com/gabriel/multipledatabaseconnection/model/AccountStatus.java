/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gabriel.multipledatabaseconnection.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author 1222270
 */
@Entity
@Table(name = "ACCOUNT_STATUS", catalog = "")
@NamedQueries({
    @NamedQuery(name = "AccountStatus.findAll", query = "SELECT a FROM AccountStatus a"),
    @NamedQuery(name = "AccountStatus.findByAcctCurrentStatus", query = "SELECT a FROM AccountStatus a WHERE a.acctCurrentStatus = :acctCurrentStatus"),
    @NamedQuery(name = "AccountStatus.findByCodeDescription", query = "SELECT a FROM AccountStatus a WHERE a.codeDescription = :codeDescription"),
    @NamedQuery(name = "AccountStatus.findByInterfaceName", query = "SELECT a FROM AccountStatus a WHERE a.interfaceName = :interfaceName"),
    @NamedQuery(name = "AccountStatus.findByCreatedDate", query = "SELECT a FROM AccountStatus a WHERE a.createdDate = :createdDate"),
    @NamedQuery(name = "AccountStatus.findByUpdatedDate", query = "SELECT a FROM AccountStatus a WHERE a.updatedDate = :updatedDate")})
public class AccountStatus implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ACCT_CURRENT_STATUS", nullable = false, length = 10)
    private String acctCurrentStatus;
    @Basic(optional = false)
    @Column(name = "CODE_DESCRIPTION", nullable = false, length = 30)
    private String codeDescription;
    @Basic(optional = false)
    @Column(name = "INTERFACE_NAME", nullable = false, length = 10)
    private String interfaceName;
    @Basic(optional = false)
    @Column(name = "CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Column(name = "UPDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    public AccountStatus() {
    }

    public AccountStatus(String acctCurrentStatus) {
        this.acctCurrentStatus = acctCurrentStatus;
    }

    public AccountStatus(String acctCurrentStatus, String codeDescription, String interfaceName, Date createdDate) {
        this.acctCurrentStatus = acctCurrentStatus;
        this.codeDescription = codeDescription;
        this.interfaceName = interfaceName;
        this.createdDate = createdDate;
    }

    public String getAcctCurrentStatus() {
        return acctCurrentStatus;
    }

    public void setAcctCurrentStatus(String acctCurrentStatus) {
        this.acctCurrentStatus = acctCurrentStatus;
    }

    public String getCodeDescription() {
        return codeDescription;
    }

    public void setCodeDescription(String codeDescription) {
        this.codeDescription = codeDescription;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (acctCurrentStatus != null ? acctCurrentStatus.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AccountStatus)) {
            return false;
        }
        AccountStatus other = (AccountStatus) object;
        if ((this.acctCurrentStatus == null && other.acctCurrentStatus != null) || (this.acctCurrentStatus != null && !this.acctCurrentStatus.equals(other.acctCurrentStatus))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.AccountStatus[acctCurrentStatus=" + acctCurrentStatus + "]";
    }

}
