package com.gabriel.multipledatabaseconnection.repository.inmemory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.gabriel.multipledatabaseconnection.model.AccountEarningCredit;
import com.gabriel.multipledatabaseconnection.model.AccountEarningCreditPK;

public interface AccountEarningCreditRepositoryMemory extends JpaRepository<AccountEarningCredit, AccountEarningCreditPK>, JpaSpecificationExecutor<AccountEarningCredit> {

	List<AccountEarningCredit> findByAccountEarningCreditPK_countryCode(String idNumber);
}
