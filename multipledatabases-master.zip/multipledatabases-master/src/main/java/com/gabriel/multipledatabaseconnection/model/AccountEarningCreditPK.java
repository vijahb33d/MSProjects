/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gabriel.multipledatabaseconnection.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author 1222270
 */
@Embeddable
public class AccountEarningCreditPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "COUNTRY_CODE", nullable = false, length = 2)
    private String countryCode;
    @Basic(optional = false)
    @Column(name = "CURRENCY_CODE", nullable = false, length = 3)
    private String currencyCode;
    @Basic(optional = false)
    @Column(name = "ACCOUNT_NO", nullable = false, length = 35)
    private String accountNo;

    public AccountEarningCreditPK() {
    }

    public AccountEarningCreditPK(String countryCode, String currencyCode, String accountNo) {
        this.countryCode = countryCode;
        this.currencyCode = currencyCode;
        this.accountNo = accountNo;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countryCode != null ? countryCode.hashCode() : 0);
        hash += (currencyCode != null ? currencyCode.hashCode() : 0);
        hash += (accountNo != null ? accountNo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AccountEarningCreditPK)) {
            return false;
        }
        AccountEarningCreditPK other = (AccountEarningCreditPK) object;
        if ((this.countryCode == null && other.countryCode != null) || (this.countryCode != null && !this.countryCode.equals(other.countryCode))) {
            return false;
        }
        if ((this.currencyCode == null && other.currencyCode != null) || (this.currencyCode != null && !this.currencyCode.equals(other.currencyCode))) {
            return false;
        }
        if ((this.accountNo == null && other.accountNo != null) || (this.accountNo != null && !this.accountNo.equals(other.accountNo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.AccountEarningCreditPK[countryCode=" + countryCode + ", currencyCode=" + currencyCode + ", accountNo=" + accountNo + "]";
    }

}
