package com.gabriel.multipledatabaseconnection.repository.inmemory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.gabriel.multipledatabaseconnection.model.Customer;
import com.gabriel.multipledatabaseconnection.model.CustomerPK;

public interface CustomerRepositoryInMemory extends JpaRepository<Customer, CustomerPK>, JpaSpecificationExecutor<Customer> {

	List<Customer> findByCustomerPK_countryCode(String idNumber);
}
