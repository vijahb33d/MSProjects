package com.gabriel.multipledatabaseconnection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipledatabaseconnectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultipledatabaseconnectionApplication.class, args);
	}
}
