/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gabriel.multipledatabaseconnection.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author 1222270
 */
@Embeddable
public class CustomerPK implements Serializable {
    @Basic(optional = false)
    @Column(name = "COUNTRY_CODE", nullable = false, length = 2)
    private String countryCode;
    @Basic(optional = false)
    @Column(name = "MASTER_NO", nullable = false, length = 18)
    private String masterNo;

    public CustomerPK() {
    }

    public CustomerPK(String countryCode, String masterNo) {
        this.countryCode = countryCode;
        this.masterNo = masterNo;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getMasterNo() {
        return masterNo;
    }

    public void setMasterNo(String masterNo) {
        this.masterNo = masterNo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (countryCode != null ? countryCode.hashCode() : 0);
        hash += (masterNo != null ? masterNo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CustomerPK)) {
            return false;
        }
        CustomerPK other = (CustomerPK) object;
        if ((this.countryCode == null && other.countryCode != null) || (this.countryCode != null && !this.countryCode.equals(other.countryCode))) {
            return false;
        }
        if ((this.masterNo == null && other.masterNo != null) || (this.masterNo != null && !this.masterNo.equals(other.masterNo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.CustomerPK[countryCode=" + countryCode + ", masterNo=" + masterNo + "]";
    }

}
