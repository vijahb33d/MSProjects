package net.codejava.hibernate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 * Test Hibernate binary data mapping with primitive byte[] array.
 * @author www.codejava.net
 *
 */
public class PersonPhotoTest {
	private static ServiceRegistry serviceRegistry;
	private static Session session;
	
	public static void main(String[] args) throws IOException {
		initSession();
		
		String photoFilePathToRead = "e:/Test/Photo/Puppy.jpg";
		savePersonWithPhoto(photoFilePathToRead);
		
		int personId = 1;
		String photoFilePathToSave = "e:/Test/Photo/MyPuppy.jpg";
		readPhotoOfPerson(personId, photoFilePathToSave);
		
		endSession();
	}
	
	private static void savePersonWithPhoto(String photoFilePath) throws IOException {
		Person person = new Person("Tom");
		byte[] photoBytes = readBytesFromFile(photoFilePath);
		person.setPhoto(photoBytes);
		session.save(person);
	}
	
	private static void readPhotoOfPerson(int personId, String photoFilePath) throws IOException {
		Person person = (Person) session.get(Person.class, personId);
		byte[] photoBytes = person.getPhoto();
		saveBytesToFile(photoFilePath, photoBytes);
	}
	
	private static byte[] readBytesFromFile(String filePath) throws IOException {
		File inputFile = new File(filePath);
		FileInputStream inputStream = new FileInputStream(inputFile);
		
		byte[] fileBytes = new byte[(int) inputFile.length()];
		inputStream.read(fileBytes);
		inputStream.close();
		
		return fileBytes;
	}
	
	private static void saveBytesToFile(String filePath, byte[] fileBytes) throws IOException {
		FileOutputStream outputStream = new FileOutputStream(filePath);
		outputStream.write(fileBytes);
		outputStream.close();
	}
	
	
	private static void initSession() {
		Configuration configuration = new Configuration().configure();
		serviceRegistry	= new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties()).build();
		
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		
		session = sessionFactory.openSession();
		session.beginTransaction();
	}
	
	private static void endSession() {
		session.getTransaction().commit();
		session.close();
		
		StandardServiceRegistryBuilder.destroy(serviceRegistry);		
	}

}
