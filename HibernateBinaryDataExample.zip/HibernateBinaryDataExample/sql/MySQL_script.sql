CREATE DATABASE `person_db`;

CREATE TABLE `person` (
  `person_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `photo` longblob,
  PRIMARY KEY (`person_id`)
)