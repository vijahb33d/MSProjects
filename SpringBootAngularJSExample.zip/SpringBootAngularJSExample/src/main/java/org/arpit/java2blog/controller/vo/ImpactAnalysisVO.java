package org.arpit.java2blog.controller.vo;

public class ImpactAnalysisVO {
	private String projectName;
	private String appName;
	private String gpbsAppName;
	private String functionalImpact;
	private String dependencies;
	private String parameterSetup;
	private String aigRequired;
	private String globalImpact;
	private String countryApplicable;
	private String productImpact;
	private String changeCategory;
	private String technicalImpact;
	private String solutionPerformed;

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}
	/**
	 * @param appName the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}
	/**
	 * @return the gpbsAppName
	 */
	public String getGpbsAppName() {
		return gpbsAppName;
	}
	/**
	 * @param gpbsAppName the gpbsAppName to set
	 */
	public void setGpbsAppName(String gpbsAppName) {
		this.gpbsAppName = gpbsAppName;
	}
	/**
	 * @return the functionalImpact
	 */
	public String getFunctionalImpact() {
		return functionalImpact;
	}
	/**
	 * @param functionalImpact the functionalImpact to set
	 */
	public void setFunctionalImpact(String functionalImpact) {
		this.functionalImpact = functionalImpact;
	}
	/**
	 * @return the dependencies
	 */
	public String getDependencies() {
		return dependencies;
	}
	/**
	 * @param dependencies the dependencies to set
	 */
	public void setDependencies(String dependencies) {
		this.dependencies = dependencies;
	}
	/**
	 * @return the parameterSetup
	 */
	public String getParameterSetup() {
		return parameterSetup;
	}
	/**
	 * @param parameterSetup the parameterSetup to set
	 */
	public void setParameterSetup(String parameterSetup) {
		this.parameterSetup = parameterSetup;
	}
	/**
	 * @return the aigRequired
	 */
	public String getAigRequired() {
		return aigRequired;
	}
	/**
	 * @param aigRequired the aigRequired to set
	 */
	public void setAigRequired(String aigRequired) {
		this.aigRequired = aigRequired;
	}
	/**
	 * @return the globalImpact
	 */
	public String getGlobalImpact() {
		return globalImpact;
	}
	/**
	 * @param globalImpact the globalImpact to set
	 */
	public void setGlobalImpact(String globalImpact) {
		this.globalImpact = globalImpact;
	}
	/**
	 * @return the countryApplicable
	 */
	public String getCountryApplicable() {
		return countryApplicable;
	}
	/**
	 * @param countryApplicable the countryApplicable to set
	 */
	public void setCountryApplicable(String countryApplicable) {
		this.countryApplicable = countryApplicable;
	}
	/**
	 * @return the productImpact
	 */
	public String getProductImpact() {
		return productImpact;
	}
	/**
	 * @param productImpact the productImpact to set
	 */
	public void setProductImpact(String productImpact) {
		this.productImpact = productImpact;
	}
	/**
	 * @return the changeCategory
	 */
	public String getChangeCategory() {
		return changeCategory;
	}
	/**
	 * @param changeCategory the changeCategory to set
	 */
	public void setChangeCategory(String changeCategory) {
		this.changeCategory = changeCategory;
	}
	/**
	 * @return the technicalImpact
	 */
	public String getTechnicalImpact() {
		return technicalImpact;
	}
	/**
	 * @param technicalImpact the technicalImpact to set
	 */
	public void setTechnicalImpact(String technicalImpact) {
		this.technicalImpact = technicalImpact;
	}
	/**
	 * @return the solutionPerformed
	 */
	public String getSolutionPerformed() {
		return solutionPerformed;
	}
	/**
	 * @param solutionPerformed the solutionPerformed to set
	 */
	public void setSolutionPerformed(String solutionPerformed) {
		this.solutionPerformed = solutionPerformed;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ImpactAnalysisVO [ projectName=" + projectName + ", appName=" + appName + ", gpbsAppName="
				+ gpbsAppName + ", functionalImpact=" + functionalImpact + ", dependencies=" + dependencies
				+ ", parameterSetup=" + parameterSetup + ", aigRequired=" + aigRequired + ", globalImpact="
				+ globalImpact + ", countryApplicable=" + countryApplicable + ", productImpact=" + productImpact
				+ ", changeCategory=" + changeCategory + ", technicalImpact=" + technicalImpact + ", solutionPerformed="
				+ solutionPerformed + "]";
	}

}
