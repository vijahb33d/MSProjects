package org.arpit.java2blog.repository;

import java.util.Date;
import java.util.List;

import org.arpit.java2blog.model.ImpactAnalysis;
import org.arpit.java2blog.model.ImpactAnalysisPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface ImpactAnalysisRepository extends JpaRepository<ImpactAnalysis, ImpactAnalysisPK> {
	List<ImpactAnalysis> findByImpactAnalysisPK_releaseDate(Date releaseDate);
}
