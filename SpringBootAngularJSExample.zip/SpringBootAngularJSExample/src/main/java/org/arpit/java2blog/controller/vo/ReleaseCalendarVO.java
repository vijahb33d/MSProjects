package org.arpit.java2blog.controller.vo;

public class ReleaseCalendarVO {
	
	private String testingPhase;
	private String startDate;
	private String endDate;
	private String phaseStatus;
	
	/**
	 * @return the testingPhase
	 */
	public String getTestingPhase() {
		return testingPhase;
	}

	/**
	 * @param testingPhase the testingPhase to set
	 */
	public void setTestingPhase(String testingPhase) {
		this.testingPhase = testingPhase;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the phaseStatus
	 */
	public String getPhaseStatus() {
		return phaseStatus;
	}

	/**
	 * @param phaseStatus the phaseStatus to set
	 */
	public void setPhaseStatus(String phaseStatus) {
		this.phaseStatus = phaseStatus;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ReleaseCalendarVO [testingPhase=" + testingPhase + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", phaseStatus=" + phaseStatus + "]";
	}
}
