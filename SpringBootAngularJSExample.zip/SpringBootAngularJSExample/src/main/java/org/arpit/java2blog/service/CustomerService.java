package org.arpit.java2blog.service;

import java.util.List;

import org.arpit.java2blog.model.Customer;
import org.arpit.java2blog.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("customerService")
public class CustomerService {

	@Autowired
	CustomerRepository customerRepo;

	public List<Customer> getAllCustomers() {
		return customerRepo.findAll();
	}

	public Customer getCustomer(int id) {
		return customerRepo.findOne(id);
	}

	public Customer addCustomer(Customer customer) {
		customerRepo.save(customer);
		return customer;
	}

	public Customer updateCustomer(Customer customer) {
		customerRepo.save(customer);
		return customer;
	}

	public void deleteCustomer(int id) {
		customerRepo.delete(id);;
	}
}
