package org.arpit.java2blog.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Embeddable
public class ImpactAnalysisPK implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Basic(optional = false)
    @Column(name = "RELEASE_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date releaseDate;
    @Basic(optional = false)
    @Column(name = "PROJECT_NAME", nullable = false, length = 600)
    private String projectName;

    public ImpactAnalysisPK() {
    }

    public ImpactAnalysisPK(Date releaseDate, String projectName) {
        this.releaseDate = releaseDate;
        this.projectName = projectName;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (releaseDate != null ? releaseDate.hashCode() : 0);
        hash += (projectName != null ? projectName.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ImpactAnalysisPK)) {
            return false;
        }
        ImpactAnalysisPK other = (ImpactAnalysisPK) object;
        if ((this.releaseDate == null && other.releaseDate != null) || (this.releaseDate != null && !this.releaseDate.equals(other.releaseDate))) {
            return false;
        }
        if ((this.projectName == null && other.projectName != null) || (this.projectName != null && !this.projectName.equals(other.projectName))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.ImpactAnalysisPK[releaseDate=" + releaseDate + ", projectName=" + projectName + "]";
    }
}
