/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.arpit.java2blog.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author 1222270
 */
@Entity
@Table(name = "RELEASE_CALENDAR", catalog = "PUBLIC", schema = "PUBLIC")
public class ReleaseCalendar implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ReleaseCalendarPK releaseCalendarPK;
    @Basic(optional = false)
    @Column(name = "PHASE_START_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date phaseStartDate;
    @Basic(optional = false)
    @Column(name = "PHASE_END_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date phaseEndDate;
    @Basic(optional = false)
    @Column(name = "PHASE_STATUS", nullable = false, length = 30)
    private String phaseStatus;
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Column(name = "UPDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    public ReleaseCalendar() {
    }

    public ReleaseCalendar(ReleaseCalendarPK releaseCalendarPK) {
        this.releaseCalendarPK = releaseCalendarPK;
    }

    public ReleaseCalendar(ReleaseCalendarPK releaseCalendarPK, Date phaseStartDate, Date phaseEndDate, String phaseStatus) {
        this.releaseCalendarPK = releaseCalendarPK;
        this.phaseStartDate = phaseStartDate;
        this.phaseEndDate = phaseEndDate;
        this.phaseStatus = phaseStatus;
    }

    public ReleaseCalendar(Date releaseDate, String testingPhase) {
        this.releaseCalendarPK = new ReleaseCalendarPK(releaseDate, testingPhase);
    }

    public ReleaseCalendarPK getReleaseCalendarPK() {
        return releaseCalendarPK;
    }

    public void setReleaseCalendarPK(ReleaseCalendarPK releaseCalendarPK) {
        this.releaseCalendarPK = releaseCalendarPK;
    }

    public Date getPhaseStartDate() {
        return phaseStartDate;
    }

    public void setPhaseStartDate(Date phaseStartDate) {
        this.phaseStartDate = phaseStartDate;
    }

    public Date getPhaseEndDate() {
        return phaseEndDate;
    }

    public void setPhaseEndDate(Date phaseEndDate) {
        this.phaseEndDate = phaseEndDate;
    }

    public String getPhaseStatus() {
        return phaseStatus;
    }

    public void setPhaseStatus(String phaseStatus) {
        this.phaseStatus = phaseStatus;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (releaseCalendarPK != null ? releaseCalendarPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReleaseCalendar)) {
            return false;
        }
        ReleaseCalendar other = (ReleaseCalendar) object;
        if ((this.releaseCalendarPK == null && other.releaseCalendarPK != null) || (this.releaseCalendarPK != null && !this.releaseCalendarPK.equals(other.releaseCalendarPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.ReleaseCalendar[releaseCalendarPK=" + releaseCalendarPK + "]";
    }

}
