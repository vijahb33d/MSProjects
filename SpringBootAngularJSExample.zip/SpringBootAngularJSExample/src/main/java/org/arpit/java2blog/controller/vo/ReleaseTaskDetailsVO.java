package org.arpit.java2blog.controller.vo;

public class ReleaseTaskDetailsVO {	
	private Integer id;
	private String taskDesc;
	private String startDate;
	private String endDate;
	private String taskCurrentStatus;
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the taskDesc
	 */
	public String getTaskDesc() {
		return taskDesc;
	}
	/**
	 * @param taskDesc the taskDesc to set
	 */
	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}
	/**
	 * @return the taskStartDate
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @param taskStartDate the taskStartDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the taskEndDate
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @param taskEndDate the taskEndDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return the taskCurrentStatus
	 */
	public String getTaskCurrentStatus() {
		return taskCurrentStatus;
	}
	/**
	 * @param taskCurrentStatus the taskCurrentStatus to set
	 */
	public void setTaskCurrentStatus(String taskCurrentStatus) {
		this.taskCurrentStatus = taskCurrentStatus;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ReleaseTaskDetailsVO [id=" + id + ", taskDesc=" + taskDesc + ", taskStartDate=" + startDate
				+ ", taskEndDate=" + endDate + ", taskCurrentStatus=" + taskCurrentStatus + "]";
	}

}
