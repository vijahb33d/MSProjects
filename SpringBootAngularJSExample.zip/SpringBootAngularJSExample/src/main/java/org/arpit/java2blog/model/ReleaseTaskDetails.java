/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.arpit.java2blog.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author 1222270
 */
@Entity
@Table(name = "RELEASE_TASK_DETAILS", catalog = "PUBLIC", schema = "PUBLIC")
public class ReleaseTaskDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ReleaseTaskDetailsPK releaseTaskDetailsPK;
    @Basic(optional = false)
    @Column(name = "TASK_DESC", nullable = false, length = 200)
    private String taskDesc;
    @Basic(optional = false)
    @Column(name = "TASK_START_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date taskStartDate;
    @Basic(optional = false)
    @Column(name = "TASK_END_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date taskEndDate;
    @Column(name = "TASK_CURRENT_STATUS", length = 50)
    private String taskCurrentStatus;
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
    @Column(name = "UPDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    public ReleaseTaskDetails() {
    }

    public ReleaseTaskDetails(ReleaseTaskDetailsPK releaseTaskDetailsPK) {
        this.releaseTaskDetailsPK = releaseTaskDetailsPK;
    }

    public ReleaseTaskDetails(ReleaseTaskDetailsPK releaseTaskDetailsPK, String taskDesc, Date taskStartDate, Date taskEndDate) {
        this.releaseTaskDetailsPK = releaseTaskDetailsPK;
        this.taskDesc = taskDesc;
        this.taskStartDate = taskStartDate;
        this.taskEndDate = taskEndDate;
    }

    public ReleaseTaskDetails(Date releaseDate, int seqNum) {
        this.releaseTaskDetailsPK = new ReleaseTaskDetailsPK(releaseDate, seqNum);
    }

    public ReleaseTaskDetailsPK getReleaseTaskDetailsPK() {
        return releaseTaskDetailsPK;
    }

    public void setReleaseTaskDetailsPK(ReleaseTaskDetailsPK releaseTaskDetailsPK) {
        this.releaseTaskDetailsPK = releaseTaskDetailsPK;
    }

    public String getTaskDesc() {
        return taskDesc;
    }

    public void setTaskDesc(String taskDesc) {
        this.taskDesc = taskDesc;
    }

    public Date getTaskStartDate() {
        return taskStartDate;
    }

    public void setTaskStartDate(Date taskStartDate) {
        this.taskStartDate = taskStartDate;
    }

    public Date getTaskEndDate() {
        return taskEndDate;
    }

    public void setTaskEndDate(Date taskEndDate) {
        this.taskEndDate = taskEndDate;
    }

    public String getTaskCurrentStatus() {
        return taskCurrentStatus;
    }

    public void setTaskCurrentStatus(String taskCurrentStatus) {
        this.taskCurrentStatus = taskCurrentStatus;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (releaseTaskDetailsPK != null ? releaseTaskDetailsPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReleaseTaskDetails)) {
            return false;
        }
        ReleaseTaskDetails other = (ReleaseTaskDetails) object;
        if ((this.releaseTaskDetailsPK == null && other.releaseTaskDetailsPK != null) || (this.releaseTaskDetailsPK != null && !this.releaseTaskDetailsPK.equals(other.releaseTaskDetailsPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.ReleaseTaskDetails[releaseTaskDetailsPK=" + releaseTaskDetailsPK + "]";
    }

}
