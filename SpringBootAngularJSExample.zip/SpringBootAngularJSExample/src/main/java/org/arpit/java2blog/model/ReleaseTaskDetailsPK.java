/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.arpit.java2blog.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author 1222270
 */
@Embeddable
public class ReleaseTaskDetailsPK implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Basic(optional = false)
    @Column(name = "RELEASE_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date releaseDate;
    @Basic(optional = false)
    @Column(name = "SEQ_NUM", nullable = false)
    private int seqNum;

    public ReleaseTaskDetailsPK() {
    }

    public ReleaseTaskDetailsPK(Date releaseDate, int seqNum) {
        this.releaseDate = releaseDate;
        this.seqNum = seqNum;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public int getSeqNum() {
        return seqNum;
    }

    public void setSeqNum(int seqNum) {
        this.seqNum = seqNum;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (releaseDate != null ? releaseDate.hashCode() : 0);
        hash += (int) seqNum;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReleaseTaskDetailsPK)) {
            return false;
        }
        ReleaseTaskDetailsPK other = (ReleaseTaskDetailsPK) object;
        if ((this.releaseDate == null && other.releaseDate != null) || (this.releaseDate != null && !this.releaseDate.equals(other.releaseDate))) {
            return false;
        }
        if (this.seqNum != other.seqNum) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.ReleaseTaskDetailsPK[releaseDate=" + releaseDate + ", seqNum=" + seqNum + "]";
    }

}
