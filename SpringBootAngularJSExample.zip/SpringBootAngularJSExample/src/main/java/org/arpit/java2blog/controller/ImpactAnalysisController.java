package org.arpit.java2blog.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.arpit.java2blog.controller.vo.ImpactAnalysisVO;
import org.arpit.java2blog.model.ImpactAnalysis;
import org.arpit.java2blog.model.ImpactAnalysisPK;
import org.arpit.java2blog.service.ImpactAnalysisService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ImpactAnalysisController {

	@Autowired
	ImpactAnalysisService impactAnalysisService;

	@RequestMapping(value = "/getAllImpactAnalysis/{releaseDate}", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<ImpactAnalysisVO> getAllImpactAnalysiss(@PathVariable("releaseDate") String date)
			throws ParseException {
		List<ImpactAnalysis> releaseDateList = impactAnalysisService.getAllImpactAnalysis(getReleaseDate(date));
		return getIAVOList(releaseDateList, getReleaseDate(date));
	}

	@RequestMapping(value = "/getImpactAnalysis/{releaseDate}/{projectName}", method = RequestMethod.GET, headers = "Accept=application/json")
	public void getImpactAnalysisById(@PathVariable String date, @PathVariable String projectName)
			throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
		java.util.Date releaseDate = sdf.parse(date);
		impactAnalysisService.getImpactAnalysis(releaseDate, projectName);
	}

	@RequestMapping(value = "/addImpactAnalysis/{releaseDate}/{projectName}", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<ImpactAnalysisVO> addImpactAnalysis(@RequestBody ImpactAnalysisVO impactAnalysisVO,
			@PathVariable("releaseDate") String date, @PathVariable("projectName") String projectName)
			throws ParseException {
		ImpactAnalysis impactAnalysis = new ImpactAnalysis();
		convertVOToEntity(impactAnalysisVO, impactAnalysis, getReleaseDate(date));
		List<ImpactAnalysis> listOfIA = impactAnalysisService.updateImpactAnalysis(impactAnalysis,getReleaseDate(date));
		return getIAVOList(listOfIA, getReleaseDate(date));
	}

	@RequestMapping(value = "/updateImpactAnalysis/{releaseDate}/{projectName}", method = RequestMethod.PUT, headers = "Accept=application/json")
	public List<ImpactAnalysisVO> updateImpactAnalysis(@RequestBody ImpactAnalysisVO impactAnalysisVO,
			@PathVariable("releaseDate") String date, @PathVariable("projectName") String projectName)
			throws ParseException {
		ImpactAnalysis impactAnalysis = new ImpactAnalysis();
		convertVOToEntity(impactAnalysisVO, impactAnalysis, getReleaseDate(date));
		List<ImpactAnalysis> listOfIA = impactAnalysisService.updateImpactAnalysis(impactAnalysis,getReleaseDate(date));
		return getIAVOList(listOfIA, getReleaseDate(date));
	}

	@RequestMapping(value = "/deleteImpactAnalysis/{releaseDate}/{projectName}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public List<ImpactAnalysisVO> deleteImpactAnalysis(@PathVariable("releaseDate") String date,
			@PathVariable("projectName") String projectName) throws ParseException {
		List<ImpactAnalysis> listOfIA = impactAnalysisService.deleteImpactAnalysis(getReleaseDate(date), projectName);
		return getIAVOList(listOfIA, getReleaseDate(date));
	}

	private void convertVOToEntity(ImpactAnalysisVO vo, ImpactAnalysis entity, Date releaseDate) {
		ImpactAnalysisPK impactAnalysisPK = new ImpactAnalysisPK(releaseDate, vo.getProjectName());
		entity.setImpactAnalysisPK(impactAnalysisPK);
		BeanUtils.copyProperties(vo, entity);
	}

	private void convertEntityToVO(ImpactAnalysis entity, ImpactAnalysisVO vo, Date releaseDate) {
		vo.setProjectName(entity.getImpactAnalysisPK().getProjectName());
		BeanUtils.copyProperties(entity, vo);
	}

	private List<ImpactAnalysisVO> getIAVOList(List<ImpactAnalysis> listOfIA, Date releaseDate) {
		List<ImpactAnalysisVO> listOfIAVO = new ArrayList<ImpactAnalysisVO>();
		for (Iterator<ImpactAnalysis> iaIter = listOfIA.iterator(); iaIter.hasNext();) {
			ImpactAnalysis ia = iaIter.next();
			ImpactAnalysisVO vo = new ImpactAnalysisVO();
			convertEntityToVO(ia, vo, releaseDate);
			listOfIAVO.add(vo);
		}
		return listOfIAVO;
	}

	private Date getReleaseDate(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
		return sdf.parse(date);
	}
}
