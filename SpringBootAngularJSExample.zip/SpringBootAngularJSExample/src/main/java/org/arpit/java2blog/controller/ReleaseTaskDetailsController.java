package org.arpit.java2blog.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.arpit.java2blog.controller.vo.ReleaseTaskDetailsVO;
import org.arpit.java2blog.model.ReleaseTaskDetails;
import org.arpit.java2blog.model.ReleaseTaskDetailsPK;
import org.arpit.java2blog.service.ReleaseTaskDetailsService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ReleaseTaskDetailsController {

	@Autowired
	ReleaseTaskDetailsService releaseTaskDetailsService;

	@RequestMapping(value = "/getAllReleaseTaskDetails/{releaseDate}", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<ReleaseTaskDetailsVO> getAllReleaseTaskDetailss(@PathVariable("releaseDate") String date)
			throws ParseException {
		List<ReleaseTaskDetails> listOfReleaseTaskDetailss = releaseTaskDetailsService
				.getAllReleaseTaskDetails(getReleaseDate(date));
		return getRTDVOList(listOfReleaseTaskDetailss, getReleaseDate(date));
	}

	@RequestMapping(value = "/getReleaseTaskDetails/{releaseDate}/{seqNum}", method = RequestMethod.GET, headers = "Accept=application/json")
	public void getReleaseTaskDetailsById(@PathVariable("releaseDate") String date,
			@PathVariable("seqNum") Integer seqNum) throws ParseException {
		releaseTaskDetailsService.getReleaseTaskDetails(getReleaseDate(date), seqNum);
	}

	@RequestMapping(value = "/addReleaseTaskDetails/{releaseDate}/{seqNum}", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<ReleaseTaskDetailsVO> addReleaseTaskDetails(@RequestBody ReleaseTaskDetailsVO ReleaseTaskDetails,
			@PathVariable("releaseDate") String date, @PathVariable("seqNum") Integer seqNum) throws ParseException {
		ReleaseTaskDetails relTaskDetails = new ReleaseTaskDetails();
		convertVOToEntity(ReleaseTaskDetails, relTaskDetails, getReleaseDate(date));
		List<ReleaseTaskDetails> listOfIA = releaseTaskDetailsService.updateReleaseTaskDetails(relTaskDetails,
				getReleaseDate(date));
		return getRTDVOList(listOfIA, getReleaseDate(date));
	}

	@RequestMapping(value = "/updateReleaseTaskDetails/{releaseDate}/{seqNum}", method = RequestMethod.PUT, headers = "Accept=application/json")
	public List<ReleaseTaskDetailsVO> updateReleaseTaskDetails(@RequestBody ReleaseTaskDetailsVO ReleaseTaskDetails,
			@PathVariable("releaseDate") String date, @PathVariable("seqNum") Integer seqNum) throws ParseException {
		ReleaseTaskDetails relTaskDetails = new ReleaseTaskDetails();
		convertVOToEntity(ReleaseTaskDetails, relTaskDetails, getReleaseDate(date));
		List<ReleaseTaskDetails> listOfIA = releaseTaskDetailsService.updateReleaseTaskDetails(relTaskDetails,
				getReleaseDate(date));
		return getRTDVOList(listOfIA, getReleaseDate(date));
	}

	@RequestMapping(value = "/deleteReleaseTaskDetails/{releaseDate}/{seqNum}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public List<ReleaseTaskDetailsVO> deleteReleaseTaskDetails(@PathVariable("releaseDate") String date,
			@PathVariable("seqNum") Integer seqNum) throws ParseException {
		List<ReleaseTaskDetails> listOfIA = releaseTaskDetailsService.deleteReleaseTaskDetails(getReleaseDate(date),
				seqNum);
		return getRTDVOList(listOfIA, getReleaseDate(date));
	}

	private void convertVOToEntity(ReleaseTaskDetailsVO vo, ReleaseTaskDetails entity, Date releaseDate) throws ParseException {
		ReleaseTaskDetailsPK releaseTaskDetailsPK = new ReleaseTaskDetailsPK(releaseDate, vo.getId());
		entity.setReleaseTaskDetailsPK(releaseTaskDetailsPK);
		BeanUtils.copyProperties(vo, entity);
		entity.setTaskStartDate(getReleaseDate(vo.getStartDate()));
		entity.setTaskEndDate(getReleaseDate(vo.getEndDate()));
	}

	private void convertEntityToVO(ReleaseTaskDetails entity, ReleaseTaskDetailsVO vo, Date releaseDate) {
		vo.setId(entity.getReleaseTaskDetailsPK().getSeqNum());
		BeanUtils.copyProperties(entity, vo);
		vo.setStartDate(getDateText(entity.getTaskStartDate()));
		vo.setEndDate(getDateText(entity.getTaskEndDate()));
	}

	private List<ReleaseTaskDetailsVO> getRTDVOList(List<ReleaseTaskDetails> listOfIA, Date releaseDate) {
		List<ReleaseTaskDetailsVO> listOfIAVO = new ArrayList<ReleaseTaskDetailsVO>();
		for (Iterator<ReleaseTaskDetails> iaIter = listOfIA.iterator(); iaIter.hasNext();) {
			ReleaseTaskDetails ia = iaIter.next();
			ReleaseTaskDetailsVO vo = new ReleaseTaskDetailsVO();
			convertEntityToVO(ia, vo, releaseDate);
			listOfIAVO.add(vo);
		}
		return listOfIAVO;
	}

	private Date getReleaseDate(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
		return sdf.parse(date);
	}
	
	private String getDateText(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		return sdf.format(date);
	}
}
