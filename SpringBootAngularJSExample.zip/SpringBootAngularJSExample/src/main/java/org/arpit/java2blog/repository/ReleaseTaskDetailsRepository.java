package org.arpit.java2blog.repository;

import java.util.Date;
import java.util.List;

import org.arpit.java2blog.model.ReleaseTaskDetails;
import org.arpit.java2blog.model.ReleaseTaskDetailsPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface ReleaseTaskDetailsRepository extends JpaRepository<ReleaseTaskDetails, ReleaseTaskDetailsPK> {
	List<ReleaseTaskDetails> findByReleaseTaskDetailsPK_releaseDate(Date releaseDate);
}
