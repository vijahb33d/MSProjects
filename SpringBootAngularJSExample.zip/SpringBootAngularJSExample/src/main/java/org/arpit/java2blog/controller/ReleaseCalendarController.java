package org.arpit.java2blog.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.arpit.java2blog.controller.vo.ReleaseCalendarVO;
import org.arpit.java2blog.model.ReleaseCalendar;
import org.arpit.java2blog.model.ReleaseCalendarPK;
import org.arpit.java2blog.service.ReleaseCalendarService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ReleaseCalendarController {

	@Autowired
	ReleaseCalendarService releaseCalendarService;

	@RequestMapping(value = "/getAllReleaseCalendar/{releaseDate}", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<ReleaseCalendarVO> getAllReleaseCalendars(@PathVariable("releaseDate") String date)
			throws ParseException {
		List<ReleaseCalendar> listOfReleaseCalendars = releaseCalendarService
				.getAllReleaseCalendar(getReleaseDate(date));
		return getRTDVOList(listOfReleaseCalendars, getReleaseDate(date));
	}

	@RequestMapping(value = "/getReleaseCalendar/{releaseDate}/{testingPhase}", method = RequestMethod.GET, headers = "Accept=application/json")
	public void getReleaseCalendarById(@PathVariable("releaseDate") String date,
			@PathVariable("testingPhase") String testingPhase) throws ParseException {
		releaseCalendarService.getReleaseCalendar(getReleaseDate(date), testingPhase);
	}

	@RequestMapping(value = "/addReleaseCalendar/{releaseDate}/{testingPhase}", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<ReleaseCalendarVO> addReleaseCalendar(@RequestBody ReleaseCalendarVO ReleaseCalendar,
			@PathVariable("releaseDate") String date, @PathVariable("testingPhase") String testingPhase) throws ParseException {
		ReleaseCalendar relTaskDetails = new ReleaseCalendar();
		convertVOToEntity(ReleaseCalendar, relTaskDetails, getReleaseDate(date));
		List<ReleaseCalendar> listOfIA = releaseCalendarService.updateReleaseCalendar(relTaskDetails,
				getReleaseDate(date));
		return getRTDVOList(listOfIA, getReleaseDate(date));
	}

	@RequestMapping(value = "/updateReleaseCalendar/{releaseDate}/{testingPhase}", method = RequestMethod.PUT, headers = "Accept=application/json")
	public List<ReleaseCalendarVO> updateReleaseCalendar(@RequestBody ReleaseCalendarVO ReleaseCalendar,
			@PathVariable("releaseDate") String date, @PathVariable("testingPhase") String testingPhase) throws ParseException {
		ReleaseCalendar relTaskDetails = new ReleaseCalendar();
		convertVOToEntity(ReleaseCalendar, relTaskDetails, getReleaseDate(date));
		List<ReleaseCalendar> listOfIA = releaseCalendarService.updateReleaseCalendar(relTaskDetails,
				getReleaseDate(date));
		return getRTDVOList(listOfIA, getReleaseDate(date));
	}

	@RequestMapping(value = "/deleteReleaseCalendar/{releaseDate}/{testingPhase}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public List<ReleaseCalendarVO> deleteReleaseCalendar(@PathVariable("releaseDate") String date,
			@PathVariable("testingPhase") String testingPhase) throws ParseException {
		List<ReleaseCalendar> listOfIA = releaseCalendarService.deleteReleaseCalendar(getReleaseDate(date),testingPhase);
		return getRTDVOList(listOfIA, getReleaseDate(date));
	}

	private void convertVOToEntity(ReleaseCalendarVO vo, ReleaseCalendar entity, Date releaseDate) throws ParseException {
		ReleaseCalendarPK ReleaseCalendarPK = new ReleaseCalendarPK(releaseDate, vo.getTestingPhase());
		entity.setReleaseCalendarPK(ReleaseCalendarPK);
		BeanUtils.copyProperties(vo, entity);
		entity.setPhaseStartDate(getReleaseDate(vo.getStartDate()));
		entity.setPhaseEndDate(getReleaseDate(vo.getEndDate()));
	}

	private void convertEntityToVO(ReleaseCalendar entity, ReleaseCalendarVO vo, Date releaseDate) {
		vo.setTestingPhase(entity.getReleaseCalendarPK().getTestingPhase());
		BeanUtils.copyProperties(entity, vo);
		vo.setStartDate(getDateText(entity.getPhaseStartDate()));
		vo.setEndDate(getDateText(entity.getPhaseEndDate()));
	}

	private List<ReleaseCalendarVO> getRTDVOList(List<ReleaseCalendar> listOfIA, Date releaseDate) {
		List<ReleaseCalendarVO> listOfIAVO = new ArrayList<ReleaseCalendarVO>();
		for (Iterator<ReleaseCalendar> iaIter = listOfIA.iterator(); iaIter.hasNext();) {
			ReleaseCalendar ia = iaIter.next();
			ReleaseCalendarVO vo = new ReleaseCalendarVO();
			convertEntityToVO(ia, vo, releaseDate);
			listOfIAVO.add(vo);
		}
		return listOfIAVO;
	}

	private Date getReleaseDate(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
		return sdf.parse(date);
	}
	
	private String getDateText(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		return sdf.format(date);
	}
}
