package org.arpit.java2blog.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/*
 * This is our model class and it corresponds to Customer table in database
 */
@Entity
@Table(name="IMPACT_ANALYSIS")
public class ImpactAnalysis implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ImpactAnalysisPK impactAnalysisPK;
    @Column(name = "APP_NAME", length = 100)
    private String appName;
    @Column(name = "GPBS_APP_NAME", length = 150)
    private String gpbsAppName;
    @Column(name = "FUNCTIONAL_IMPACT", length = 2000)
    private String functionalImpact;
    @Column(name = "DEPENDENCIES", length = 1500)
    private String dependencies;
    @Column(name = "PARAMETER_SETUP", length = 150)
    private String parameterSetup;
    @Column(name = "AIG_REQUIRED", length = 600)
    private String aigRequired;
    @Column(name = "GLOBAL_IMPACT", length = 80)
    private String globalImpact;
    @Column(name = "COUNTRY_APPLICABLE", length = 80)
    private String countryApplicable;
    @Column(name = "PRODUCT_IMPACT", length = 1500)
    private String productImpact;
    @Column(name = "CHANGE_CATEGORY", length = 40)
    private String changeCategory;
    @Column(name = "TECHNICAL_IMPACT", length = 2000)
    private String technicalImpact;
    @Column(name = "SOLUTION_PERFORMED", length = 2000)
    private String solutionPerformed;

    public ImpactAnalysis() {
    }

    public ImpactAnalysis(ImpactAnalysisPK impactAnalysisPK) {
        this.impactAnalysisPK = impactAnalysisPK;
    }

    public ImpactAnalysis(Date releaseDate, String projectName) {
        this.impactAnalysisPK = new ImpactAnalysisPK(releaseDate, projectName);
    }

    public ImpactAnalysisPK getImpactAnalysisPK() {
        return impactAnalysisPK;
    }

    public void setImpactAnalysisPK(ImpactAnalysisPK impactAnalysisPK) {
        this.impactAnalysisPK = impactAnalysisPK;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getGpbsAppName() {
        return gpbsAppName;
    }

    public void setGpbsAppName(String gpbsAppName) {
        this.gpbsAppName = gpbsAppName;
    }

    public String getFunctionalImpact() {
        return functionalImpact;
    }

    public void setFunctionalImpact(String functionalImpact) {
        this.functionalImpact = functionalImpact;
    }

    public String getDependencies() {
        return dependencies;
    }

    public void setDependencies(String dependencies) {
        this.dependencies = dependencies;
    }

    public String getParameterSetup() {
        return parameterSetup;
    }

    public void setParameterSetup(String parameterSetup) {
        this.parameterSetup = parameterSetup;
    }

    public String getAigRequired() {
        return aigRequired;
    }

    public void setAigRequired(String aigRequired) {
        this.aigRequired = aigRequired;
    }

    public String getGlobalImpact() {
        return globalImpact;
    }

    public void setGlobalImpact(String globalImpact) {
        this.globalImpact = globalImpact;
    }

    public String getCountryApplicable() {
        return countryApplicable;
    }

    public void setCountryApplicable(String countryApplicable) {
        this.countryApplicable = countryApplicable;
    }

    public String getProductImpact() {
        return productImpact;
    }

    public void setProductImpact(String productImpact) {
        this.productImpact = productImpact;
    }

    public String getChangeCategory() {
        return changeCategory;
    }

    public void setChangeCategory(String changeCategory) {
        this.changeCategory = changeCategory;
    }

    public String getTechnicalImpact() {
        return technicalImpact;
    }

    public void setTechnicalImpact(String technicalImpact) {
        this.technicalImpact = technicalImpact;
    }

    public String getSolutionPerformed() {
        return solutionPerformed;
    }

    public void setSolutionPerformed(String solutionPerformed) {
        this.solutionPerformed = solutionPerformed;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (impactAnalysisPK != null ? impactAnalysisPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ImpactAnalysis)) {
            return false;
        }
        ImpactAnalysis other = (ImpactAnalysis) object;
        if ((this.impactAnalysisPK == null && other.impactAnalysisPK != null) || (this.impactAnalysisPK != null && !this.impactAnalysisPK.equals(other.impactAnalysisPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.ImpactAnalysis[impactAnalysisPK=" + impactAnalysisPK + "]";
    }
}
