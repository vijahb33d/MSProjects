/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.arpit.java2blog.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author 1222270
 */
@Embeddable
public class ReleaseCalendarPK implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Basic(optional = false)
    @Column(name = "RELEASE_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date releaseDate;
    @Basic(optional = false)
    @Column(name = "TESTING_PHASE", nullable = false, length = 20)
    private String testingPhase;

    public ReleaseCalendarPK() {
    }

    public ReleaseCalendarPK(Date releaseDate, String testingPhase) {
        this.releaseDate = releaseDate;
        this.testingPhase = testingPhase;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getTestingPhase() {
        return testingPhase;
    }

    public void setTestingPhase(String testingPhase) {
        this.testingPhase = testingPhase;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (releaseDate != null ? releaseDate.hashCode() : 0);
        hash += (testingPhase != null ? testingPhase.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReleaseCalendarPK)) {
            return false;
        }
        ReleaseCalendarPK other = (ReleaseCalendarPK) object;
        if ((this.releaseDate == null && other.releaseDate != null) || (this.releaseDate != null && !this.releaseDate.equals(other.releaseDate))) {
            return false;
        }
        if ((this.testingPhase == null && other.testingPhase != null) || (this.testingPhase != null && !this.testingPhase.equals(other.testingPhase))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.arpit.java2blog.model.ReleaseCalendarPK[releaseDate=" + releaseDate + ", testingPhase=" + testingPhase + "]";
    }

}
