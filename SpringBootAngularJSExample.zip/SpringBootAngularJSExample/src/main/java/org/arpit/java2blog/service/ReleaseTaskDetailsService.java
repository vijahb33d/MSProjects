package org.arpit.java2blog.service;

import java.util.Date;
import java.util.List;

import org.arpit.java2blog.model.ReleaseTaskDetails;
import org.arpit.java2blog.model.ReleaseTaskDetailsPK;
import org.arpit.java2blog.repository.ReleaseTaskDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("releaseTaskDetailsService")
public class ReleaseTaskDetailsService {

	@Autowired
	ReleaseTaskDetailsRepository releaseTaskDetailsRepo;

	public List<ReleaseTaskDetails> getAllReleaseTaskDetails(Date releaseDate) {
		return releaseTaskDetailsRepo.findByReleaseTaskDetailsPK_releaseDate(releaseDate);
	}

	public ReleaseTaskDetails getReleaseTaskDetails(Date releaseDate, Integer seqNum) {
		ReleaseTaskDetailsPK impactPK = new ReleaseTaskDetailsPK(releaseDate, seqNum);
		return releaseTaskDetailsRepo.findOne(impactPK);
	}

	public List<ReleaseTaskDetails>  addReleaseTaskDetails(ReleaseTaskDetails ReleaseTaskDetails, Date releaseDate) {
		releaseTaskDetailsRepo.save(ReleaseTaskDetails);
		return getAllReleaseTaskDetails(releaseDate);
	}

	public List<ReleaseTaskDetails> updateReleaseTaskDetails(ReleaseTaskDetails ReleaseTaskDetails, Date releaseDate) {
		releaseTaskDetailsRepo.save(ReleaseTaskDetails);
		return getAllReleaseTaskDetails(releaseDate);
	}

	public List<ReleaseTaskDetails> deleteReleaseTaskDetails(Date releaseDate, Integer seqNum) {
		ReleaseTaskDetailsPK impactPK = new ReleaseTaskDetailsPK(releaseDate, seqNum);
		releaseTaskDetailsRepo.delete(impactPK);
		return getAllReleaseTaskDetails(releaseDate);
	}
}
