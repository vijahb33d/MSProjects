package org.arpit.java2blog.service;

import java.util.Date;
import java.util.List;

import org.arpit.java2blog.model.ImpactAnalysis;
import org.arpit.java2blog.model.ImpactAnalysisPK;
import org.arpit.java2blog.repository.ImpactAnalysisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("impactAnalysisService")
public class ImpactAnalysisService {

	@Autowired
	ImpactAnalysisRepository impactAnalysisRepo;

	public List<ImpactAnalysis> getAllImpactAnalysis(Date releaseDate) {
		return impactAnalysisRepo.findByImpactAnalysisPK_releaseDate(releaseDate);
	}

	public ImpactAnalysis getImpactAnalysis(Date releaseDate, String projectName) {
		ImpactAnalysisPK impactPK = new ImpactAnalysisPK(releaseDate, projectName);
		return impactAnalysisRepo.findOne(impactPK);
	}

	public List<ImpactAnalysis>  addImpactAnalysis(ImpactAnalysis ImpactAnalysis,Date releaseDate) {
		impactAnalysisRepo.save(ImpactAnalysis);
		return getAllImpactAnalysis(releaseDate);
	}

	public List<ImpactAnalysis> updateImpactAnalysis(ImpactAnalysis ImpactAnalysis,Date releaseDate) {
		impactAnalysisRepo.save(ImpactAnalysis);
		return getAllImpactAnalysis(releaseDate);
	}

	public List<ImpactAnalysis> deleteImpactAnalysis(Date releaseDate, String projectName) {
		ImpactAnalysisPK impactPK = new ImpactAnalysisPK(releaseDate, projectName);
		impactAnalysisRepo.delete(impactPK);
		return getAllImpactAnalysis(releaseDate);
	}
}
