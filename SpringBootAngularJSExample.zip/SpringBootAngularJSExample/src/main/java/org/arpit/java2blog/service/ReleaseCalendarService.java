package org.arpit.java2blog.service;

import java.util.Date;
import java.util.List;

import org.arpit.java2blog.model.ReleaseCalendar;
import org.arpit.java2blog.model.ReleaseCalendarPK;
import org.arpit.java2blog.repository.ReleaseCalendarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("ReleaseCalendarService")
public class ReleaseCalendarService {

	@Autowired
	ReleaseCalendarRepository releaseCalendarRepo;

	public List<ReleaseCalendar> getAllReleaseCalendar(Date releaseDate) {
		return releaseCalendarRepo.findByReleaseCalendarPK_releaseDate(releaseDate);
	}

	public ReleaseCalendar getReleaseCalendar(Date releaseDate, String testingPhase) {
		ReleaseCalendarPK impactPK = new ReleaseCalendarPK(releaseDate, testingPhase);
		return releaseCalendarRepo.findOne(impactPK);
	}

	public List<ReleaseCalendar>  addReleaseCalendar(ReleaseCalendar releaseCalendar, Date releaseDate) {
		releaseCalendarRepo.save(releaseCalendar);
		return getAllReleaseCalendar(releaseDate);
	}

	public List<ReleaseCalendar> updateReleaseCalendar(ReleaseCalendar releaseCalendar, Date releaseDate) {
		releaseCalendarRepo.save(releaseCalendar);
		return getAllReleaseCalendar(releaseDate);
	}

	public List<ReleaseCalendar> deleteReleaseCalendar(Date releaseDate, String testingPhase) {
		ReleaseCalendarPK impactPK = new ReleaseCalendarPK(releaseDate, testingPhase);
		releaseCalendarRepo.delete(impactPK);
		return getAllReleaseCalendar(releaseDate);
	}
}
