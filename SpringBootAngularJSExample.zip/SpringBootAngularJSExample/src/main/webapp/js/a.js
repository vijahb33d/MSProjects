var filterDemo = angular.module('filterDemo',['ngGrid','ui.directives']);

filterDemo.controller('tabsController', function($scope,$rootScope, $http,$window){
	var landingUrl = window.location.href;
	var baseUrl = landingUrl.substring(0,landingUrl.lastIndexOf('/'));
	console.log('base url --> '+baseUrl);
	$scope.tabs = [
		{
			name: 'Release Calendar',
			url: 'aa.html',
			active1: true
		},{
			name: 'Impact Analysis',
			url: 'b.html',
			active1: true
		},{
			name: 'Release Task Details',
			url: 'c.html',
			active1: false
		}
	];
	$scope.tab = 'b.html'; /*default tab*/
	$scope.current = 'Impact Analysis'; /*default active tab*/
	$scope.toggleTab = function(s){
		$scope.tab = s.url;  /*tab changed*/
		$scope.current = s.name; /* changing value of current*/
	};	
	$scope.getWeeksInMonth=function(){
		$scope.weeks=[];
		var d = new Date();
		var month = d.getMonth();
		var mondays = [];
		d.setDate(1);
		while (d.getDay() !== 6) { 
			d.setDate(d.getDate() + 1); 
		}
		while (d.getMonth() === month) { 
			$scope.weeks.push(new Date(d.getTime())); d.setDate(d.getDate() + 7); 
		}
		$scope.weeks=$scope.weeks.splice(2,2);
	}
	$scope.getChildData = function() {
		console.log($scope.date);
		$scope.disableEdit = false;
		$scope.disableRelEdit = false;
		$scope.disableRCEdit = false;
		$scope.refreshRelData();
		$scope.refreshIAData();
		$scope.refreshRCData();
		$scope.testing();
	}
	$scope.clearData = function() {
		$scope.date="";
		$scope.rcData=[];
		$scope.myData=[];
		$scope.rcMyData=[];
		$scope.clearRelData();
		$scope.clearIAData();
		$scope.clearRCData();
		$scope.disableEdit = true;
		$scope.disableRelEdit = true;
		$scope.disableRCEdit = true;
	}
	//Select Data for all Pages
	$scope.statuses=["Not Yet","Started","WIP","Complete"];
	$scope.ids=["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20"];
	$scope.phases=["ST","SIT","UAT","RT","Pre-Prod"];

	$scope.disableEdit = true;
	$scope.disableRelEdit = true;
	$scope.disableRCEdit = true;
	//Implementation Section
	$scope.myData=[];	
	$scope.iagridOptions = {
	    data:'myData',
	    enableRowSelection:true,
	    showGridFooter:true,
	    enableRowselection:true,
	    showSelectionCheckbox:true,
	    selectWithCheckboxOnly:true,
	    multiSelect:false,
	    selectedItems:[],	    
	    afterSelectionChange:function(row) {
	    	$scope.setRowData(row)
	  }
	};
	$scope.iagridOptions.columnDefs= [		
	    { displayName : 'Project Overview', field: 'projectName' , width: "75%"}, 
	    { displayName : 'Delete', field: 'deleteAction', width: "10%", cellTemplate: '<a href="" ng-click= "deleteRow(row);"> <img src="Images/DeleteIcon2.png"/></a>'}
	];
	$scope.clearIAData = function() {
		$scope.collectedData.projectName="";
		$scope.collectedData.appName="";
		$scope.collectedData.gpbsAppName="";
		$scope.collectedData.functionalImpact="";
		$scope.collectedData.dependencies="";
		$scope.collectedData.parameterSetup="";
		$scope.collectedData.aigRequired="";
		$scope.collectedData.globalImpact="";
		$scope.collectedData.countryApplicable="";
		$scope.collectedData.productImpact="";
		$scope.collectedData.changeCategory="";
		$scope.collectedData.technicalImpact="";
		$scope.collectedData.solutionPerformed="";
	}
	$scope.selectedRowIndex=null;
	$scope.setRowData = function(val){
		$scope.collectedData = val.entity;
		$scope.selectedRowIndex = val.rowIndex;
    }
	$scope.refreshIAData =function() {
		$http.get(baseUrl+"/getAllImpactAnalysis/"+$scope.date).success(function (data, status){
			$scope.myData = data;
			$scope.collectedData={};
			$scope.clearIAData();
			console.log("status:" + status);
			console.log("myData: "+data);
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		})
	}
	$scope.addRow = function(collectedVal){
		collectedVal.releaseDate=$scope.date;
		console.log(collectedVal);
		$http.post(baseUrl+"/addImpactAnalysis/"+$scope.date+"/"+collectedVal.projectName,collectedVal).success(function (data, status){
			$scope.myData = data;
			console.log("status:" + status);
			window.alert("Row added Successfully");
			$scope.clearIAData();
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		    window.alert("Error While Adding New Record");
		})
	};	
	$scope.deleteRow = function(collectedVal) {
		$http.delete(baseUrl+"/deleteImpactAnalysis/"+$scope.date+"/"+collectedVal.entity.projectName).success(function (data, status){
			$scope.myData = data;
			console.log("status:" + status);
			window.alert("Row deleted Successfully");
			$scope.clearIAData();
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		    window.alert("Error While Adding New Record");
		})
	};
	$scope.saveRow = function(collectedVal){
		console.log(collectedVal);
		$scope.iagridOptions.data[$scope.selectedRowIndex] = collectedVal;
		$scope.iagridOptions.selectedItems[$scope.selectedRowIndex] = collectedVal;
		console.log("Inside Save Row at the last "+$scope.date+"/"+collectedVal.projectName);
		$http.put(baseUrl+"/updateImpactAnalysis/"+$scope.date+"/"+collectedVal.projectName,collectedVal).success(function (data, status){
			$scope.myData = data;
			console.log("status:" + status);
			window.alert("Row updated Successfully");
			$scope.clearIAData();
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		})
	}
	//Release Task Details Section
	$scope.rcMyData=[];	
	$scope.rcgridOptions = {
	    data:'rcMyData',
	    enableRowSelection:true,
	    showGridFooter:true,
	    enableRowselection:true,
	    showSelectionCheckbox:true,
	    selectWithCheckboxOnly:true,
	    multiSelect:false,
	    selectedItems:[],
	    afterSelectionChange:function(row) {
	    	$scope.setRCRowData(row)
	    }
	};
	$scope.rcgridOptions.columnDefs= [		
	    { displayName : 'ID', field: 'id', width: "5%"},	
	    { displayName : 'Task Description', field: 'taskDesc' , width: "47%"}, 
	    { displayName : 'Start Date', field: 'startDate', width: "15%"},
	    { displayName : 'End Date', field: 'endDate', width: "15%"},
	    { displayName : 'Current Status', field: 'taskCurrentStatus', width: "10%"},
	    { displayName : 'Delete', field: 'deleteAction', width: "8%", cellTemplate: '<a href="" ng-click= "deleteRCRow(row);"> <img src="Images/DeleteIcon2.png"/></a>'}
	];
	$scope.clearRCData = function() {
		$scope.rccollectedData.id="";
		$scope.rccollectedData.taskDesc="";
		$scope.rccollectedData.startDate="";
		$scope.rccollectedData.endDate="";
		$scope.rccollectedData.taskCurrentStatus="";
		$scope.rccollectedData.selectedVal="";
	}
	$scope.rcselectedRowIndex=null;
	$scope.setRCRowData = function(val){
		$scope.rccollectedData = val.entity;
		$scope.rcselectedRowIndex = val.rowIndex;
    }
	$scope.refreshRCData =function() {
		$http.get(baseUrl+"/getAllReleaseTaskDetails/"+$scope.date).success(function (data, status){
			if(data.length > 0) {
				$scope.rcMyData = data;
				$scope.rccollectedData={};
				$scope.clearRCData();
				console.log("RC My Data :" + $scope.rcMyData);
			}			
			console.log("status:" + status);
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		})
	}
	$scope.addRCRow = function(rccollectedVal){
		rccollectedVal.releaseDate=$scope.date;
		console.log(rccollectedVal);
		$http.post(baseUrl+"/addReleaseTaskDetails/"+$scope.date+"/"+rccollectedVal.id,rccollectedVal).success(function (data, status){
			$scope.rcMyData = data;
			console.log("status:" + status);
			window.alert("RTC Row added Successfully");
			$scope.clearRCData();
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		    window.alert("Error While Adding New Record");
		})
	};	
	$scope.deleteRCRow = function(rccollectedVal) {
		$http.delete(baseUrl+"/deleteReleaseTaskDetails/"+$scope.date+"/"+rccollectedVal.entity.id).success(function (data, status){
			$scope.rcMyData = data;
			console.log("status:" + status);
			window.alert("Row deleted Successfully");
			$scope.clearRCData();
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		    window.alert("Error While Adding New Record");
		})
	};	
	$scope.saveRCRow = function(rccollectedVal){
		console.log(rccollectedVal);
		$scope.rcgridOptions.data[$scope.rcselectedRowIndex] = rccollectedVal;
		$scope.rcgridOptions.selectedItems[$scope.rcselectedRowIndex] = rccollectedVal;
		console.log("Inside Save Row at the last "+$scope.date+"/"+rccollectedVal.id);
		$http.put(baseUrl+"/updateReleaseTaskDetails/"+$scope.date+"/"+rccollectedVal.id,rccollectedVal).success(function (data, status){
			$scope.rcMyData = data;
			console.log("status:" + status);
			window.alert("Row updated Successfully");
			$scope.clearRCData();
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		})
	}
	
	//Release Calendar Section
	$scope.rcData=[];	
	$scope.relgridOptions = {
	    data:'rcData',
	    enableRowSelection:true,
	    showGridFooter:true,
	    enableRowselection:true,
	    showSelectionCheckbox:true,
	    selectWithCheckboxOnly:true,
	    multiSelect:false,
	    selectedItems:[],	    
	    afterSelectionChange:function(row) {
	    	$scope.setRelRowData(row)
	  }
	};
	$scope.relgridOptions.columnDefs= [		
	    { displayName : 'Testing Phase', field: 'testingPhase' , width: "20%"},
	    { displayName : 'Phase Start Date', field: 'startDate' , width: "20%"},
	    { displayName : 'Phase End Date', field: 'endDate' , width: "20%"},
	    { displayName : 'Phase Status', field: 'phaseStatus' , width: "25%"},
	    { displayName : 'Delete', field: 'deleteAction', width: "15%", cellTemplate: '<a href="" ng-click= "deleteRelRow(row);"> <img src="Images/DeleteIcon2.png"/></a>'}
	];
	$scope.clearRelData = function() {
		$scope.relCollectedData.testingPhase="";
		$scope.relCollectedData.startDate="";
		$scope.relCollectedData.endDate="";
		$scope.relCollectedData.phaseStatus="";
	}
	$scope.relselectedRowIndex=null;
	$scope.setRelRowData = function(val){
		$scope.relCollectedData = val.entity;
		$scope.relselectedRowIndex = val.rowIndex;
    }
	$scope.refreshRelData =function() {
		$http.get(baseUrl+"/getAllReleaseCalendar/"+$scope.date).success(function (data, status){
			$scope.rcData = data;
			$scope.relCollectedData={};
			$scope.clearRelData();
			console.log("status:" + status);
			console.log("myData: "+data);
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		})
	}
	$scope.addRelRow = function(relCollectedVal){
		relCollectedVal.releaseDate=$scope.date;
		console.log(relCollectedVal);
		$http.post(baseUrl+"/addReleaseCalendar/"+$scope.date+"/"+relCollectedVal.testingPhase,relCollectedVal).success(function (data, status){
			$scope.rcData = data;
			console.log("status:" + status);
			window.alert("Row added Successfully");
			$scope.clearRelData();
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		    window.alert("Error While Adding New Record");
		})
	};	
	$scope.deleteRelRow = function(relCollectedVal) {
		$http.delete(baseUrl+"/deleteReleaseCalendar/"+$scope.date+"/"+relCollectedVal.entity.testingPhase).success(function (data, status){
			$scope.rcData = data;
			console.log("status:" + status);
			window.alert("Row deleted Successfully");
			$scope.clearRelData();
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		    window.alert("Error While Adding New Record");
		})
	};
	$scope.saveRelRow = function(relCollectedVal){
		console.log(relCollectedVal);
		$scope.relgridOptions.data[$scope.relselectedRowIndex] = relCollectedVal;
		$scope.relgridOptions.selectedItems[$scope.selectedRowIndex] = relCollectedVal;
		console.log("Inside Save Row at the last "+$scope.date+"/"+relCollectedVal.projectName);
		$http.put(baseUrl+"/updateReleaseCalendar/"+$scope.date+"/"+relCollectedVal.testingPhase,relCollectedVal).success(function (data, status){
			$scope.rcData = data;
			console.log("status:" + status);
			window.alert("Row updated Successfully");
			$scope.clearRelData();
		}).error(function(data, status) {
		    console.error('Error occurred:', data, status);
		})
	}
	
	$scope.hideDiv = function(){
		$scope.showAddRow = false;
		$scope.iagridOptions.data.push({"projectName": "'"+$scope.projectName+"'" ,"appName": "'"+$scope.appName+"'" ,"gpbsAppName": "'"+$scope.gpbsAppName+"'"});
	};
	
	$scope.testing = function(role){
		console.log("I'm a "+ role);
	}
});

filterDemo.directive('jqdatepicker', function () {
    return {
        //restrict: 'A',
        //require: 'ngModel',
        link: function (scope, element, attrs, tabsController) {
            element.datepicker({
                dateFormat: 'dd-M-yy',
                onSelect: function (date) {
                    scope.date = date;
                    scope.$apply("tabs.refreshIAData()");                                    }
            });
        }
    };
});