package com.mkyong.common;

public class App 
{
    public static void main( String[] args )
    {
    	//...
    	
    }
}
