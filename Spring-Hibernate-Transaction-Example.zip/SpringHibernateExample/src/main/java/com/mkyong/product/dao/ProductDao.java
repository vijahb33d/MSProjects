package com.mkyong.product.dao;

import com.mkyong.product.model.Product;

public interface ProductDao {
	
	void save(Product product);
	
}
