package com.mkyong.product.bo;

import com.mkyong.product.model.ProductQoh;

public interface ProductQohBo {
	
	void save(ProductQoh productQoh);
	
}
