package com.mkyong.product.dao;

import com.mkyong.product.model.ProductQoh;

public interface ProductQohDao {
	
	void save(ProductQoh productQoh);
	
}
