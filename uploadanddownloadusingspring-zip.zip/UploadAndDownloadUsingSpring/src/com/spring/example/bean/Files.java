/*
 * Copyright (c) 2010
 */
package com.spring.example.bean;

/**
 * @author: gardiary
 * @created: Apr 5, 2010 , 1:55:06 PM
 * $Id: Files.java 18395 2010-04-05 13:55:00Z gardiary $
 */
public class Files {
    private int id;
    private String filename;
    private String notes;
    private String type;
    private byte[] file;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public byte[] getFile() {
        return file;
    }

    public void setFile(byte[] file) {
        this.file = file;
    }
}
